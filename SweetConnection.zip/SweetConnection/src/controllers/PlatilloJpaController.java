/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.exceptions.NonexistentEntityException;
import controllers.exceptions.PreexistingEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entities.Ingredientes;
import java.util.ArrayList;
import java.util.Collection;
import entities.Orden;
import entities.Platillo;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author murdo
 */
public class PlatilloJpaController implements Serializable {

    public PlatilloJpaController() {
        this.emf = Persistence.createEntityManagerFactory("SweetConnectionPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Platillo platillo) throws PreexistingEntityException, Exception {
        if (platillo.getIngredientesCollection() == null) {
            platillo.setIngredientesCollection(new ArrayList<Ingredientes>());
        }
        if (platillo.getOrdenCollection() == null) {
            platillo.setOrdenCollection(new ArrayList<Orden>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Ingredientes> attachedIngredientesCollection = new ArrayList<Ingredientes>();
            for (Ingredientes ingredientesCollectionIngredientesToAttach : platillo.getIngredientesCollection()) {
                ingredientesCollectionIngredientesToAttach = em.getReference(ingredientesCollectionIngredientesToAttach.getClass(), ingredientesCollectionIngredientesToAttach.getIDIngrediente());
                attachedIngredientesCollection.add(ingredientesCollectionIngredientesToAttach);
            }
            platillo.setIngredientesCollection(attachedIngredientesCollection);
            Collection<Orden> attachedOrdenCollection = new ArrayList<Orden>();
            for (Orden ordenCollectionOrdenToAttach : platillo.getOrdenCollection()) {
                ordenCollectionOrdenToAttach = em.getReference(ordenCollectionOrdenToAttach.getClass(), ordenCollectionOrdenToAttach.getNumOrden());
                attachedOrdenCollection.add(ordenCollectionOrdenToAttach);
            }
            platillo.setOrdenCollection(attachedOrdenCollection);
            em.persist(platillo);
            for (Ingredientes ingredientesCollectionIngredientes : platillo.getIngredientesCollection()) {
                ingredientesCollectionIngredientes.getPlatilloCollection().add(platillo);
                ingredientesCollectionIngredientes = em.merge(ingredientesCollectionIngredientes);
            }
            for (Orden ordenCollectionOrden : platillo.getOrdenCollection()) {
                Platillo oldIDPlatilloOfOrdenCollectionOrden = ordenCollectionOrden.getIDPlatillo();
                ordenCollectionOrden.setIDPlatillo(platillo);
                ordenCollectionOrden = em.merge(ordenCollectionOrden);
                if (oldIDPlatilloOfOrdenCollectionOrden != null) {
                    oldIDPlatilloOfOrdenCollectionOrden.getOrdenCollection().remove(ordenCollectionOrden);
                    oldIDPlatilloOfOrdenCollectionOrden = em.merge(oldIDPlatilloOfOrdenCollectionOrden);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findPlatillo(platillo.getIDPlatillo()) != null) {
                throw new PreexistingEntityException("Platillo " + platillo + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Platillo platillo) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Platillo persistentPlatillo = em.find(Platillo.class, platillo.getIDPlatillo());
            Collection<Ingredientes> ingredientesCollectionOld = persistentPlatillo.getIngredientesCollection();
            Collection<Ingredientes> ingredientesCollectionNew = platillo.getIngredientesCollection();
            Collection<Orden> ordenCollectionOld = persistentPlatillo.getOrdenCollection();
            Collection<Orden> ordenCollectionNew = platillo.getOrdenCollection();
            Collection<Ingredientes> attachedIngredientesCollectionNew = new ArrayList<Ingredientes>();
            for (Ingredientes ingredientesCollectionNewIngredientesToAttach : ingredientesCollectionNew) {
                ingredientesCollectionNewIngredientesToAttach = em.getReference(ingredientesCollectionNewIngredientesToAttach.getClass(), ingredientesCollectionNewIngredientesToAttach.getIDIngrediente());
                attachedIngredientesCollectionNew.add(ingredientesCollectionNewIngredientesToAttach);
            }
            ingredientesCollectionNew = attachedIngredientesCollectionNew;
            platillo.setIngredientesCollection(ingredientesCollectionNew);
            Collection<Orden> attachedOrdenCollectionNew = new ArrayList<Orden>();
            for (Orden ordenCollectionNewOrdenToAttach : ordenCollectionNew) {
                ordenCollectionNewOrdenToAttach = em.getReference(ordenCollectionNewOrdenToAttach.getClass(), ordenCollectionNewOrdenToAttach.getNumOrden());
                attachedOrdenCollectionNew.add(ordenCollectionNewOrdenToAttach);
            }
            ordenCollectionNew = attachedOrdenCollectionNew;
            platillo.setOrdenCollection(ordenCollectionNew);
            platillo = em.merge(platillo);
            for (Ingredientes ingredientesCollectionOldIngredientes : ingredientesCollectionOld) {
                if (!ingredientesCollectionNew.contains(ingredientesCollectionOldIngredientes)) {
                    ingredientesCollectionOldIngredientes.getPlatilloCollection().remove(platillo);
                    ingredientesCollectionOldIngredientes = em.merge(ingredientesCollectionOldIngredientes);
                }
            }
            for (Ingredientes ingredientesCollectionNewIngredientes : ingredientesCollectionNew) {
                if (!ingredientesCollectionOld.contains(ingredientesCollectionNewIngredientes)) {
                    ingredientesCollectionNewIngredientes.getPlatilloCollection().add(platillo);
                    ingredientesCollectionNewIngredientes = em.merge(ingredientesCollectionNewIngredientes);
                }
            }
            for (Orden ordenCollectionOldOrden : ordenCollectionOld) {
                if (!ordenCollectionNew.contains(ordenCollectionOldOrden)) {
                    ordenCollectionOldOrden.setIDPlatillo(null);
                    ordenCollectionOldOrden = em.merge(ordenCollectionOldOrden);
                }
            }
            for (Orden ordenCollectionNewOrden : ordenCollectionNew) {
                if (!ordenCollectionOld.contains(ordenCollectionNewOrden)) {
                    Platillo oldIDPlatilloOfOrdenCollectionNewOrden = ordenCollectionNewOrden.getIDPlatillo();
                    ordenCollectionNewOrden.setIDPlatillo(platillo);
                    ordenCollectionNewOrden = em.merge(ordenCollectionNewOrden);
                    if (oldIDPlatilloOfOrdenCollectionNewOrden != null && !oldIDPlatilloOfOrdenCollectionNewOrden.equals(platillo)) {
                        oldIDPlatilloOfOrdenCollectionNewOrden.getOrdenCollection().remove(ordenCollectionNewOrden);
                        oldIDPlatilloOfOrdenCollectionNewOrden = em.merge(oldIDPlatilloOfOrdenCollectionNewOrden);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = platillo.getIDPlatillo();
                if (findPlatillo(id) == null) {
                    throw new NonexistentEntityException("The platillo with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Platillo platillo;
            try {
                platillo = em.getReference(Platillo.class, id);
                platillo.getIDPlatillo();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The platillo with id " + id + " no longer exists.", enfe);
            }
            Collection<Ingredientes> ingredientesCollection = platillo.getIngredientesCollection();
            for (Ingredientes ingredientesCollectionIngredientes : ingredientesCollection) {
                ingredientesCollectionIngredientes.getPlatilloCollection().remove(platillo);
                ingredientesCollectionIngredientes = em.merge(ingredientesCollectionIngredientes);
            }
            Collection<Orden> ordenCollection = platillo.getOrdenCollection();
            for (Orden ordenCollectionOrden : ordenCollection) {
                ordenCollectionOrden.setIDPlatillo(null);
                ordenCollectionOrden = em.merge(ordenCollectionOrden);
            }
            em.remove(platillo);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Platillo> findPlatilloEntities() {
        return findPlatilloEntities(true, -1, -1);
    }

    public List<Platillo> findPlatilloEntities(int maxResults, int firstResult) {
        return findPlatilloEntities(false, maxResults, firstResult);
    }

    private List<Platillo> findPlatilloEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Platillo.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Platillo findPlatillo(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Platillo.class, id);
        } finally {
            em.close();
        }
    }

    public int getPlatilloCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Platillo> rt = cq.from(Platillo.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
