/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.exceptions.NonexistentEntityException;
import controllers.exceptions.PreexistingEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entities.Platillo;
import entities.Mesero;
import entities.Orden;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author murdo
 */
public class OrdenJpaController implements Serializable {

    public OrdenJpaController() {
        this.emf = Persistence.createEntityManagerFactory("SweetConnectionPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Orden orden) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Platillo IDPlatillo = orden.getIDPlatillo();
            if (IDPlatillo != null) {
                IDPlatillo = em.getReference(IDPlatillo.getClass(), IDPlatillo.getIDPlatillo());
                orden.setIDPlatillo(IDPlatillo);
            }
            Mesero IDMesero = orden.getIDMesero();
            if (IDMesero != null) {
                IDMesero = em.getReference(IDMesero.getClass(), IDMesero.getIDMesero());
                orden.setIDMesero(IDMesero);
            }
            em.persist(orden);
            if (IDPlatillo != null) {
                IDPlatillo.getOrdenCollection().add(orden);
                IDPlatillo = em.merge(IDPlatillo);
            }
            if (IDMesero != null) {
                IDMesero.getOrdenCollection().add(orden);
                IDMesero = em.merge(IDMesero);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findOrden(orden.getNumOrden()) != null) {
                throw new PreexistingEntityException("Orden " + orden + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Orden orden) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Orden persistentOrden = em.find(Orden.class, orden.getNumOrden());
            Platillo IDPlatilloOld = persistentOrden.getIDPlatillo();
            Platillo IDPlatilloNew = orden.getIDPlatillo();
            Mesero IDMeseroOld = persistentOrden.getIDMesero();
            Mesero IDMeseroNew = orden.getIDMesero();
            if (IDPlatilloNew != null) {
                IDPlatilloNew = em.getReference(IDPlatilloNew.getClass(), IDPlatilloNew.getIDPlatillo());
                orden.setIDPlatillo(IDPlatilloNew);
            }
            if (IDMeseroNew != null) {
                IDMeseroNew = em.getReference(IDMeseroNew.getClass(), IDMeseroNew.getIDMesero());
                orden.setIDMesero(IDMeseroNew);
            }
            orden = em.merge(orden);
            if (IDPlatilloOld != null && !IDPlatilloOld.equals(IDPlatilloNew)) {
                IDPlatilloOld.getOrdenCollection().remove(orden);
                IDPlatilloOld = em.merge(IDPlatilloOld);
            }
            if (IDPlatilloNew != null && !IDPlatilloNew.equals(IDPlatilloOld)) {
                IDPlatilloNew.getOrdenCollection().add(orden);
                IDPlatilloNew = em.merge(IDPlatilloNew);
            }
            if (IDMeseroOld != null && !IDMeseroOld.equals(IDMeseroNew)) {
                IDMeseroOld.getOrdenCollection().remove(orden);
                IDMeseroOld = em.merge(IDMeseroOld);
            }
            if (IDMeseroNew != null && !IDMeseroNew.equals(IDMeseroOld)) {
                IDMeseroNew.getOrdenCollection().add(orden);
                IDMeseroNew = em.merge(IDMeseroNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = orden.getNumOrden();
                if (findOrden(id) == null) {
                    throw new NonexistentEntityException("The orden with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Orden orden;
            try {
                orden = em.getReference(Orden.class, id);
                orden.getNumOrden();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The orden with id " + id + " no longer exists.", enfe);
            }
            Platillo IDPlatillo = orden.getIDPlatillo();
            if (IDPlatillo != null) {
                IDPlatillo.getOrdenCollection().remove(orden);
                IDPlatillo = em.merge(IDPlatillo);
            }
            Mesero IDMesero = orden.getIDMesero();
            if (IDMesero != null) {
                IDMesero.getOrdenCollection().remove(orden);
                IDMesero = em.merge(IDMesero);
            }
            em.remove(orden);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Orden> findOrdenEntities() {
        return findOrdenEntities(true, -1, -1);
    }

    public List<Orden> findOrdenEntities(int maxResults, int firstResult) {
        return findOrdenEntities(false, maxResults, firstResult);
    }

    private List<Orden> findOrdenEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Orden.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Orden findOrden(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Orden.class, id);
        } finally {
            em.close();
        }
    }

    public int getOrdenCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Orden> rt = cq.from(Orden.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
