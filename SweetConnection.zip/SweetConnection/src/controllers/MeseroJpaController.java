/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.exceptions.NonexistentEntityException;
import controllers.exceptions.PreexistingEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entities.Horario;
import entities.Mesas;
import entities.Mesero;
import java.util.ArrayList;
import java.util.Collection;
import entities.Orden;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author murdo
 */
public class MeseroJpaController implements Serializable {

    public MeseroJpaController() {
        this.emf = Persistence.createEntityManagerFactory("SweetConnectionPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Mesero mesero) throws PreexistingEntityException, Exception {
        if (mesero.getMesasCollection() == null) {
            mesero.setMesasCollection(new ArrayList<Mesas>());
        }
        if (mesero.getOrdenCollection() == null) {
            mesero.setOrdenCollection(new ArrayList<Orden>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Horario IDHorario = mesero.getIDHorario();
            if (IDHorario != null) {
                IDHorario = em.getReference(IDHorario.getClass(), IDHorario.getIDHorario());
                mesero.setIDHorario(IDHorario);
            }
            Collection<Mesas> attachedMesasCollection = new ArrayList<Mesas>();
            for (Mesas mesasCollectionMesasToAttach : mesero.getMesasCollection()) {
                mesasCollectionMesasToAttach = em.getReference(mesasCollectionMesasToAttach.getClass(), mesasCollectionMesasToAttach.getIDMesa());
                attachedMesasCollection.add(mesasCollectionMesasToAttach);
            }
            mesero.setMesasCollection(attachedMesasCollection);
            Collection<Orden> attachedOrdenCollection = new ArrayList<Orden>();
            for (Orden ordenCollectionOrdenToAttach : mesero.getOrdenCollection()) {
                ordenCollectionOrdenToAttach = em.getReference(ordenCollectionOrdenToAttach.getClass(), ordenCollectionOrdenToAttach.getNumOrden());
                attachedOrdenCollection.add(ordenCollectionOrdenToAttach);
            }
            mesero.setOrdenCollection(attachedOrdenCollection);
            em.persist(mesero);
            if (IDHorario != null) {
                IDHorario.getMeseroCollection().add(mesero);
                IDHorario = em.merge(IDHorario);
            }
            for (Mesas mesasCollectionMesas : mesero.getMesasCollection()) {
                Mesero oldIDMeseroOfMesasCollectionMesas = mesasCollectionMesas.getIDMesero();
                mesasCollectionMesas.setIDMesero(mesero);
                mesasCollectionMesas = em.merge(mesasCollectionMesas);
                if (oldIDMeseroOfMesasCollectionMesas != null) {
                    oldIDMeseroOfMesasCollectionMesas.getMesasCollection().remove(mesasCollectionMesas);
                    oldIDMeseroOfMesasCollectionMesas = em.merge(oldIDMeseroOfMesasCollectionMesas);
                }
            }
            for (Orden ordenCollectionOrden : mesero.getOrdenCollection()) {
                Mesero oldIDMeseroOfOrdenCollectionOrden = ordenCollectionOrden.getIDMesero();
                ordenCollectionOrden.setIDMesero(mesero);
                ordenCollectionOrden = em.merge(ordenCollectionOrden);
                if (oldIDMeseroOfOrdenCollectionOrden != null) {
                    oldIDMeseroOfOrdenCollectionOrden.getOrdenCollection().remove(ordenCollectionOrden);
                    oldIDMeseroOfOrdenCollectionOrden = em.merge(oldIDMeseroOfOrdenCollectionOrden);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findMesero(mesero.getIDMesero()) != null) {
                throw new PreexistingEntityException("Mesero " + mesero + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Mesero mesero) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Mesero persistentMesero = em.find(Mesero.class, mesero.getIDMesero());
            Horario IDHorarioOld = persistentMesero.getIDHorario();
            Horario IDHorarioNew = mesero.getIDHorario();
            Collection<Mesas> mesasCollectionOld = persistentMesero.getMesasCollection();
            Collection<Mesas> mesasCollectionNew = mesero.getMesasCollection();
            Collection<Orden> ordenCollectionOld = persistentMesero.getOrdenCollection();
            Collection<Orden> ordenCollectionNew = mesero.getOrdenCollection();
            if (IDHorarioNew != null) {
                IDHorarioNew = em.getReference(IDHorarioNew.getClass(), IDHorarioNew.getIDHorario());
                mesero.setIDHorario(IDHorarioNew);
            }
            Collection<Mesas> attachedMesasCollectionNew = new ArrayList<Mesas>();
            for (Mesas mesasCollectionNewMesasToAttach : mesasCollectionNew) {
                mesasCollectionNewMesasToAttach = em.getReference(mesasCollectionNewMesasToAttach.getClass(), mesasCollectionNewMesasToAttach.getIDMesa());
                attachedMesasCollectionNew.add(mesasCollectionNewMesasToAttach);
            }
            mesasCollectionNew = attachedMesasCollectionNew;
            mesero.setMesasCollection(mesasCollectionNew);
            Collection<Orden> attachedOrdenCollectionNew = new ArrayList<Orden>();
            for (Orden ordenCollectionNewOrdenToAttach : ordenCollectionNew) {
                ordenCollectionNewOrdenToAttach = em.getReference(ordenCollectionNewOrdenToAttach.getClass(), ordenCollectionNewOrdenToAttach.getNumOrden());
                attachedOrdenCollectionNew.add(ordenCollectionNewOrdenToAttach);
            }
            ordenCollectionNew = attachedOrdenCollectionNew;
            mesero.setOrdenCollection(ordenCollectionNew);
            mesero = em.merge(mesero);
            if (IDHorarioOld != null && !IDHorarioOld.equals(IDHorarioNew)) {
                IDHorarioOld.getMeseroCollection().remove(mesero);
                IDHorarioOld = em.merge(IDHorarioOld);
            }
            if (IDHorarioNew != null && !IDHorarioNew.equals(IDHorarioOld)) {
                IDHorarioNew.getMeseroCollection().add(mesero);
                IDHorarioNew = em.merge(IDHorarioNew);
            }
            for (Mesas mesasCollectionOldMesas : mesasCollectionOld) {
                if (!mesasCollectionNew.contains(mesasCollectionOldMesas)) {
                    mesasCollectionOldMesas.setIDMesero(null);
                    mesasCollectionOldMesas = em.merge(mesasCollectionOldMesas);
                }
            }
            for (Mesas mesasCollectionNewMesas : mesasCollectionNew) {
                if (!mesasCollectionOld.contains(mesasCollectionNewMesas)) {
                    Mesero oldIDMeseroOfMesasCollectionNewMesas = mesasCollectionNewMesas.getIDMesero();
                    mesasCollectionNewMesas.setIDMesero(mesero);
                    mesasCollectionNewMesas = em.merge(mesasCollectionNewMesas);
                    if (oldIDMeseroOfMesasCollectionNewMesas != null && !oldIDMeseroOfMesasCollectionNewMesas.equals(mesero)) {
                        oldIDMeseroOfMesasCollectionNewMesas.getMesasCollection().remove(mesasCollectionNewMesas);
                        oldIDMeseroOfMesasCollectionNewMesas = em.merge(oldIDMeseroOfMesasCollectionNewMesas);
                    }
                }
            }
            for (Orden ordenCollectionOldOrden : ordenCollectionOld) {
                if (!ordenCollectionNew.contains(ordenCollectionOldOrden)) {
                    ordenCollectionOldOrden.setIDMesero(null);
                    ordenCollectionOldOrden = em.merge(ordenCollectionOldOrden);
                }
            }
            for (Orden ordenCollectionNewOrden : ordenCollectionNew) {
                if (!ordenCollectionOld.contains(ordenCollectionNewOrden)) {
                    Mesero oldIDMeseroOfOrdenCollectionNewOrden = ordenCollectionNewOrden.getIDMesero();
                    ordenCollectionNewOrden.setIDMesero(mesero);
                    ordenCollectionNewOrden = em.merge(ordenCollectionNewOrden);
                    if (oldIDMeseroOfOrdenCollectionNewOrden != null && !oldIDMeseroOfOrdenCollectionNewOrden.equals(mesero)) {
                        oldIDMeseroOfOrdenCollectionNewOrden.getOrdenCollection().remove(ordenCollectionNewOrden);
                        oldIDMeseroOfOrdenCollectionNewOrden = em.merge(oldIDMeseroOfOrdenCollectionNewOrden);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = mesero.getIDMesero();
                if (findMesero(id) == null) {
                    throw new NonexistentEntityException("The mesero with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Mesero mesero;
            try {
                mesero = em.getReference(Mesero.class, id);
                mesero.getIDMesero();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The mesero with id " + id + " no longer exists.", enfe);
            }
            Horario IDHorario = mesero.getIDHorario();
            if (IDHorario != null) {
                IDHorario.getMeseroCollection().remove(mesero);
                IDHorario = em.merge(IDHorario);
            }
            Collection<Mesas> mesasCollection = mesero.getMesasCollection();
            for (Mesas mesasCollectionMesas : mesasCollection) {
                mesasCollectionMesas.setIDMesero(null);
                mesasCollectionMesas = em.merge(mesasCollectionMesas);
            }
            Collection<Orden> ordenCollection = mesero.getOrdenCollection();
            for (Orden ordenCollectionOrden : ordenCollection) {
                ordenCollectionOrden.setIDMesero(null);
                ordenCollectionOrden = em.merge(ordenCollectionOrden);
            }
            em.remove(mesero);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Mesero> findMeseroEntities() {
        return findMeseroEntities(true, -1, -1);
    }

    public List<Mesero> findMeseroEntities(int maxResults, int firstResult) {
        return findMeseroEntities(false, maxResults, firstResult);
    }

    private List<Mesero> findMeseroEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Mesero.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Mesero findMesero(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Mesero.class, id);
        } finally {
            em.close();
        }
    }

    public int getMeseroCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Mesero> rt = cq.from(Mesero.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
