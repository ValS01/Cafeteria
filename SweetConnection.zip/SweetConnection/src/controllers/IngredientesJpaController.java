/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.exceptions.NonexistentEntityException;
import controllers.exceptions.PreexistingEntityException;
import entities.Ingredientes;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entities.Platillo;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author murdo
 */
public class IngredientesJpaController implements Serializable {

    public IngredientesJpaController() {
        this.emf = Persistence.createEntityManagerFactory("SweetConnectionPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Ingredientes ingredientes) throws PreexistingEntityException, Exception {
        if (ingredientes.getPlatilloCollection() == null) {
            ingredientes.setPlatilloCollection(new ArrayList<Platillo>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Platillo> attachedPlatilloCollection = new ArrayList<Platillo>();
            for (Platillo platilloCollectionPlatilloToAttach : ingredientes.getPlatilloCollection()) {
                platilloCollectionPlatilloToAttach = em.getReference(platilloCollectionPlatilloToAttach.getClass(), platilloCollectionPlatilloToAttach.getIDPlatillo());
                attachedPlatilloCollection.add(platilloCollectionPlatilloToAttach);
            }
            ingredientes.setPlatilloCollection(attachedPlatilloCollection);
            em.persist(ingredientes);
            for (Platillo platilloCollectionPlatillo : ingredientes.getPlatilloCollection()) {
                platilloCollectionPlatillo.getIngredientesCollection().add(ingredientes);
                platilloCollectionPlatillo = em.merge(platilloCollectionPlatillo);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findIngredientes(ingredientes.getIDIngrediente()) != null) {
                throw new PreexistingEntityException("Ingredientes " + ingredientes + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Ingredientes ingredientes) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Ingredientes persistentIngredientes = em.find(Ingredientes.class, ingredientes.getIDIngrediente());
            Collection<Platillo> platilloCollectionOld = persistentIngredientes.getPlatilloCollection();
            Collection<Platillo> platilloCollectionNew = ingredientes.getPlatilloCollection();
            Collection<Platillo> attachedPlatilloCollectionNew = new ArrayList<Platillo>();
            for (Platillo platilloCollectionNewPlatilloToAttach : platilloCollectionNew) {
                platilloCollectionNewPlatilloToAttach = em.getReference(platilloCollectionNewPlatilloToAttach.getClass(), platilloCollectionNewPlatilloToAttach.getIDPlatillo());
                attachedPlatilloCollectionNew.add(platilloCollectionNewPlatilloToAttach);
            }
            platilloCollectionNew = attachedPlatilloCollectionNew;
            ingredientes.setPlatilloCollection(platilloCollectionNew);
            ingredientes = em.merge(ingredientes);
            for (Platillo platilloCollectionOldPlatillo : platilloCollectionOld) {
                if (!platilloCollectionNew.contains(platilloCollectionOldPlatillo)) {
                    platilloCollectionOldPlatillo.getIngredientesCollection().remove(ingredientes);
                    platilloCollectionOldPlatillo = em.merge(platilloCollectionOldPlatillo);
                }
            }
            for (Platillo platilloCollectionNewPlatillo : platilloCollectionNew) {
                if (!platilloCollectionOld.contains(platilloCollectionNewPlatillo)) {
                    platilloCollectionNewPlatillo.getIngredientesCollection().add(ingredientes);
                    platilloCollectionNewPlatillo = em.merge(platilloCollectionNewPlatillo);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = ingredientes.getIDIngrediente();
                if (findIngredientes(id) == null) {
                    throw new NonexistentEntityException("The ingredientes with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Ingredientes ingredientes;
            try {
                ingredientes = em.getReference(Ingredientes.class, id);
                ingredientes.getIDIngrediente();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The ingredientes with id " + id + " no longer exists.", enfe);
            }
            Collection<Platillo> platilloCollection = ingredientes.getPlatilloCollection();
            for (Platillo platilloCollectionPlatillo : platilloCollection) {
                platilloCollectionPlatillo.getIngredientesCollection().remove(ingredientes);
                platilloCollectionPlatillo = em.merge(platilloCollectionPlatillo);
            }
            em.remove(ingredientes);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Ingredientes> findIngredientesEntities() {
        return findIngredientesEntities(true, -1, -1);
    }

    public List<Ingredientes> findIngredientesEntities(int maxResults, int firstResult) {
        return findIngredientesEntities(false, maxResults, firstResult);
    }

    private List<Ingredientes> findIngredientesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Ingredientes.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Ingredientes findIngredientes(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Ingredientes.class, id);
        } finally {
            em.close();
        }
    }

    public int getIngredientesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Ingredientes> rt = cq.from(Ingredientes.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
