/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.exceptions.NonexistentEntityException;
import controllers.exceptions.PreexistingEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entities.Cajero;
import entities.Reservaciones;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author murdo
 */
public class ReservacionesJpaController implements Serializable {

    public ReservacionesJpaController() {
        this.emf = Persistence.createEntityManagerFactory("SweetConnectionPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Reservaciones reservaciones) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cajero IDCajero = reservaciones.getIDCajero();
            if (IDCajero != null) {
                IDCajero = em.getReference(IDCajero.getClass(), IDCajero.getIDCajero());
                reservaciones.setIDCajero(IDCajero);
            }
            em.persist(reservaciones);
            if (IDCajero != null) {
                IDCajero.getReservacionesCollection().add(reservaciones);
                IDCajero = em.merge(IDCajero);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findReservaciones(reservaciones.getIDReservacion()) != null) {
                throw new PreexistingEntityException("Reservaciones " + reservaciones + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Reservaciones reservaciones) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Reservaciones persistentReservaciones = em.find(Reservaciones.class, reservaciones.getIDReservacion());
            Cajero IDCajeroOld = persistentReservaciones.getIDCajero();
            Cajero IDCajeroNew = reservaciones.getIDCajero();
            if (IDCajeroNew != null) {
                IDCajeroNew = em.getReference(IDCajeroNew.getClass(), IDCajeroNew.getIDCajero());
                reservaciones.setIDCajero(IDCajeroNew);
            }
            reservaciones = em.merge(reservaciones);
            if (IDCajeroOld != null && !IDCajeroOld.equals(IDCajeroNew)) {
                IDCajeroOld.getReservacionesCollection().remove(reservaciones);
                IDCajeroOld = em.merge(IDCajeroOld);
            }
            if (IDCajeroNew != null && !IDCajeroNew.equals(IDCajeroOld)) {
                IDCajeroNew.getReservacionesCollection().add(reservaciones);
                IDCajeroNew = em.merge(IDCajeroNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = reservaciones.getIDReservacion();
                if (findReservaciones(id) == null) {
                    throw new NonexistentEntityException("The reservaciones with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Reservaciones reservaciones;
            try {
                reservaciones = em.getReference(Reservaciones.class, id);
                reservaciones.getIDReservacion();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The reservaciones with id " + id + " no longer exists.", enfe);
            }
            Cajero IDCajero = reservaciones.getIDCajero();
            if (IDCajero != null) {
                IDCajero.getReservacionesCollection().remove(reservaciones);
                IDCajero = em.merge(IDCajero);
            }
            em.remove(reservaciones);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Reservaciones> findReservacionesEntities() {
        return findReservacionesEntities(true, -1, -1);
    }

    public List<Reservaciones> findReservacionesEntities(int maxResults, int firstResult) {
        return findReservacionesEntities(false, maxResults, firstResult);
    }

    private List<Reservaciones> findReservacionesEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Reservaciones.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Reservaciones findReservaciones(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Reservaciones.class, id);
        } finally {
            em.close();
        }
    }

    public int getReservacionesCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Reservaciones> rt = cq.from(Reservaciones.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
