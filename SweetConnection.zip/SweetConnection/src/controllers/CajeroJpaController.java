/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.exceptions.NonexistentEntityException;
import controllers.exceptions.PreexistingEntityException;
import entities.Cajero;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entities.Horario;
import entities.Reservaciones;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author murdo
 */
public class CajeroJpaController implements Serializable {

    public CajeroJpaController() {
        this.emf = Persistence.createEntityManagerFactory("SweetConnectionPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Cajero cajero) throws PreexistingEntityException, Exception {
        if (cajero.getReservacionesCollection() == null) {
            cajero.setReservacionesCollection(new ArrayList<Reservaciones>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Horario IDHorario = cajero.getIDHorario();
            if (IDHorario != null) {
                IDHorario = em.getReference(IDHorario.getClass(), IDHorario.getIDHorario());
                cajero.setIDHorario(IDHorario);
            }
            Collection<Reservaciones> attachedReservacionesCollection = new ArrayList<Reservaciones>();
            for (Reservaciones reservacionesCollectionReservacionesToAttach : cajero.getReservacionesCollection()) {
                reservacionesCollectionReservacionesToAttach = em.getReference(reservacionesCollectionReservacionesToAttach.getClass(), reservacionesCollectionReservacionesToAttach.getIDReservacion());
                attachedReservacionesCollection.add(reservacionesCollectionReservacionesToAttach);
            }
            cajero.setReservacionesCollection(attachedReservacionesCollection);
            em.persist(cajero);
            if (IDHorario != null) {
                IDHorario.getCajeroCollection().add(cajero);
                IDHorario = em.merge(IDHorario);
            }
            for (Reservaciones reservacionesCollectionReservaciones : cajero.getReservacionesCollection()) {
                Cajero oldIDCajeroOfReservacionesCollectionReservaciones = reservacionesCollectionReservaciones.getIDCajero();
                reservacionesCollectionReservaciones.setIDCajero(cajero);
                reservacionesCollectionReservaciones = em.merge(reservacionesCollectionReservaciones);
                if (oldIDCajeroOfReservacionesCollectionReservaciones != null) {
                    oldIDCajeroOfReservacionesCollectionReservaciones.getReservacionesCollection().remove(reservacionesCollectionReservaciones);
                    oldIDCajeroOfReservacionesCollectionReservaciones = em.merge(oldIDCajeroOfReservacionesCollectionReservaciones);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findCajero(cajero.getIDCajero()) != null) {
                throw new PreexistingEntityException("Cajero " + cajero + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Cajero cajero) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cajero persistentCajero = em.find(Cajero.class, cajero.getIDCajero());
            Horario IDHorarioOld = persistentCajero.getIDHorario();
            Horario IDHorarioNew = cajero.getIDHorario();
            Collection<Reservaciones> reservacionesCollectionOld = persistentCajero.getReservacionesCollection();
            Collection<Reservaciones> reservacionesCollectionNew = cajero.getReservacionesCollection();
            if (IDHorarioNew != null) {
                IDHorarioNew = em.getReference(IDHorarioNew.getClass(), IDHorarioNew.getIDHorario());
                cajero.setIDHorario(IDHorarioNew);
            }
            Collection<Reservaciones> attachedReservacionesCollectionNew = new ArrayList<Reservaciones>();
            for (Reservaciones reservacionesCollectionNewReservacionesToAttach : reservacionesCollectionNew) {
                reservacionesCollectionNewReservacionesToAttach = em.getReference(reservacionesCollectionNewReservacionesToAttach.getClass(), reservacionesCollectionNewReservacionesToAttach.getIDReservacion());
                attachedReservacionesCollectionNew.add(reservacionesCollectionNewReservacionesToAttach);
            }
            reservacionesCollectionNew = attachedReservacionesCollectionNew;
            cajero.setReservacionesCollection(reservacionesCollectionNew);
            cajero = em.merge(cajero);
            if (IDHorarioOld != null && !IDHorarioOld.equals(IDHorarioNew)) {
                IDHorarioOld.getCajeroCollection().remove(cajero);
                IDHorarioOld = em.merge(IDHorarioOld);
            }
            if (IDHorarioNew != null && !IDHorarioNew.equals(IDHorarioOld)) {
                IDHorarioNew.getCajeroCollection().add(cajero);
                IDHorarioNew = em.merge(IDHorarioNew);
            }
            for (Reservaciones reservacionesCollectionOldReservaciones : reservacionesCollectionOld) {
                if (!reservacionesCollectionNew.contains(reservacionesCollectionOldReservaciones)) {
                    reservacionesCollectionOldReservaciones.setIDCajero(null);
                    reservacionesCollectionOldReservaciones = em.merge(reservacionesCollectionOldReservaciones);
                }
            }
            for (Reservaciones reservacionesCollectionNewReservaciones : reservacionesCollectionNew) {
                if (!reservacionesCollectionOld.contains(reservacionesCollectionNewReservaciones)) {
                    Cajero oldIDCajeroOfReservacionesCollectionNewReservaciones = reservacionesCollectionNewReservaciones.getIDCajero();
                    reservacionesCollectionNewReservaciones.setIDCajero(cajero);
                    reservacionesCollectionNewReservaciones = em.merge(reservacionesCollectionNewReservaciones);
                    if (oldIDCajeroOfReservacionesCollectionNewReservaciones != null && !oldIDCajeroOfReservacionesCollectionNewReservaciones.equals(cajero)) {
                        oldIDCajeroOfReservacionesCollectionNewReservaciones.getReservacionesCollection().remove(reservacionesCollectionNewReservaciones);
                        oldIDCajeroOfReservacionesCollectionNewReservaciones = em.merge(oldIDCajeroOfReservacionesCollectionNewReservaciones);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = cajero.getIDCajero();
                if (findCajero(id) == null) {
                    throw new NonexistentEntityException("The cajero with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cajero cajero;
            try {
                cajero = em.getReference(Cajero.class, id);
                cajero.getIDCajero();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The cajero with id " + id + " no longer exists.", enfe);
            }
            Horario IDHorario = cajero.getIDHorario();
            if (IDHorario != null) {
                IDHorario.getCajeroCollection().remove(cajero);
                IDHorario = em.merge(IDHorario);
            }
            Collection<Reservaciones> reservacionesCollection = cajero.getReservacionesCollection();
            for (Reservaciones reservacionesCollectionReservaciones : reservacionesCollection) {
                reservacionesCollectionReservaciones.setIDCajero(null);
                reservacionesCollectionReservaciones = em.merge(reservacionesCollectionReservaciones);
            }
            em.remove(cajero);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Cajero> findCajeroEntities() {
        return findCajeroEntities(true, -1, -1);
    }

    public List<Cajero> findCajeroEntities(int maxResults, int firstResult) {
        return findCajeroEntities(false, maxResults, firstResult);
    }

    private List<Cajero> findCajeroEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Cajero.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Cajero findCajero(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Cajero.class, id);
        } finally {
            em.close();
        }
    }

    public int getCajeroCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Cajero> rt = cq.from(Cajero.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
