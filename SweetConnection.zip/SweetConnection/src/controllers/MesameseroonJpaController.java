/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.exceptions.NonexistentEntityException;
import controllers.exceptions.PreexistingEntityException;
import entities.Mesameseroon;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author murdo
 */
public class MesameseroonJpaController implements Serializable {

    public MesameseroonJpaController() {
        this.emf = Persistence.createEntityManagerFactory("SweetConnectionPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Mesameseroon mesameseroon) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(mesameseroon);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findMesameseroon(mesameseroon.getContador()) != null) {
                throw new PreexistingEntityException("Mesameseroon " + mesameseroon + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Mesameseroon mesameseroon) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            mesameseroon = em.merge(mesameseroon);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = mesameseroon.getContador();
                if (findMesameseroon(id) == null) {
                    throw new NonexistentEntityException("The mesameseroon with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Mesameseroon mesameseroon;
            try {
                mesameseroon = em.getReference(Mesameseroon.class, id);
                mesameseroon.getContador();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The mesameseroon with id " + id + " no longer exists.", enfe);
            }
            em.remove(mesameseroon);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Mesameseroon> findMesameseroonEntities() {
        return findMesameseroonEntities(true, -1, -1);
    }

    public List<Mesameseroon> findMesameseroonEntities(int maxResults, int firstResult) {
        return findMesameseroonEntities(false, maxResults, firstResult);
    }

    private List<Mesameseroon> findMesameseroonEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Mesameseroon.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Mesameseroon findMesameseroon(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Mesameseroon.class, id);
        } finally {
            em.close();
        }
    }

    public int getMesameseroonCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Mesameseroon> rt = cq.from(Mesameseroon.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
