/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.exceptions.NonexistentEntityException;
import controllers.exceptions.PreexistingEntityException;
import entities.Cocinero;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entities.Horario;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author murdo
 */
public class CocineroJpaController implements Serializable {

    public CocineroJpaController() {
        this.emf = Persistence.createEntityManagerFactory("SweetConnectionPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Cocinero cocinero) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Horario IDHorario = cocinero.getIDHorario();
            if (IDHorario != null) {
                IDHorario = em.getReference(IDHorario.getClass(), IDHorario.getIDHorario());
                cocinero.setIDHorario(IDHorario);
            }
            em.persist(cocinero);
            if (IDHorario != null) {
                IDHorario.getCocineroCollection().add(cocinero);
                IDHorario = em.merge(IDHorario);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findCocinero(cocinero.getIDCocinero()) != null) {
                throw new PreexistingEntityException("Cocinero " + cocinero + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Cocinero cocinero) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cocinero persistentCocinero = em.find(Cocinero.class, cocinero.getIDCocinero());
            Horario IDHorarioOld = persistentCocinero.getIDHorario();
            Horario IDHorarioNew = cocinero.getIDHorario();
            if (IDHorarioNew != null) {
                IDHorarioNew = em.getReference(IDHorarioNew.getClass(), IDHorarioNew.getIDHorario());
                cocinero.setIDHorario(IDHorarioNew);
            }
            cocinero = em.merge(cocinero);
            if (IDHorarioOld != null && !IDHorarioOld.equals(IDHorarioNew)) {
                IDHorarioOld.getCocineroCollection().remove(cocinero);
                IDHorarioOld = em.merge(IDHorarioOld);
            }
            if (IDHorarioNew != null && !IDHorarioNew.equals(IDHorarioOld)) {
                IDHorarioNew.getCocineroCollection().add(cocinero);
                IDHorarioNew = em.merge(IDHorarioNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = cocinero.getIDCocinero();
                if (findCocinero(id) == null) {
                    throw new NonexistentEntityException("The cocinero with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cocinero cocinero;
            try {
                cocinero = em.getReference(Cocinero.class, id);
                cocinero.getIDCocinero();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The cocinero with id " + id + " no longer exists.", enfe);
            }
            Horario IDHorario = cocinero.getIDHorario();
            if (IDHorario != null) {
                IDHorario.getCocineroCollection().remove(cocinero);
                IDHorario = em.merge(IDHorario);
            }
            em.remove(cocinero);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Cocinero> findCocineroEntities() {
        return findCocineroEntities(true, -1, -1);
    }

    public List<Cocinero> findCocineroEntities(int maxResults, int firstResult) {
        return findCocineroEntities(false, maxResults, firstResult);
    }

    private List<Cocinero> findCocineroEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Cocinero.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Cocinero findCocinero(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Cocinero.class, id);
        } finally {
            em.close();
        }
    }

    public int getCocineroCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Cocinero> rt = cq.from(Cocinero.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
