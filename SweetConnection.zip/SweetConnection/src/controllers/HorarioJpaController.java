/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import controllers.exceptions.NonexistentEntityException;
import controllers.exceptions.PreexistingEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entities.Mesero;
import java.util.ArrayList;
import java.util.Collection;
import entities.Cocinero;
import entities.Cajero;
import entities.Horario;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author murdo
 */
public class HorarioJpaController implements Serializable {

    public HorarioJpaController() {
        this.emf = Persistence.createEntityManagerFactory("SweetConnectionPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Horario horario) throws PreexistingEntityException, Exception {
        if (horario.getMeseroCollection() == null) {
            horario.setMeseroCollection(new ArrayList<Mesero>());
        }
        if (horario.getCocineroCollection() == null) {
            horario.setCocineroCollection(new ArrayList<Cocinero>());
        }
        if (horario.getCajeroCollection() == null) {
            horario.setCajeroCollection(new ArrayList<Cajero>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Mesero> attachedMeseroCollection = new ArrayList<Mesero>();
            for (Mesero meseroCollectionMeseroToAttach : horario.getMeseroCollection()) {
                meseroCollectionMeseroToAttach = em.getReference(meseroCollectionMeseroToAttach.getClass(), meseroCollectionMeseroToAttach.getIDMesero());
                attachedMeseroCollection.add(meseroCollectionMeseroToAttach);
            }
            horario.setMeseroCollection(attachedMeseroCollection);
            Collection<Cocinero> attachedCocineroCollection = new ArrayList<Cocinero>();
            for (Cocinero cocineroCollectionCocineroToAttach : horario.getCocineroCollection()) {
                cocineroCollectionCocineroToAttach = em.getReference(cocineroCollectionCocineroToAttach.getClass(), cocineroCollectionCocineroToAttach.getIDCocinero());
                attachedCocineroCollection.add(cocineroCollectionCocineroToAttach);
            }
            horario.setCocineroCollection(attachedCocineroCollection);
            Collection<Cajero> attachedCajeroCollection = new ArrayList<Cajero>();
            for (Cajero cajeroCollectionCajeroToAttach : horario.getCajeroCollection()) {
                cajeroCollectionCajeroToAttach = em.getReference(cajeroCollectionCajeroToAttach.getClass(), cajeroCollectionCajeroToAttach.getIDCajero());
                attachedCajeroCollection.add(cajeroCollectionCajeroToAttach);
            }
            horario.setCajeroCollection(attachedCajeroCollection);
            em.persist(horario);
            for (Mesero meseroCollectionMesero : horario.getMeseroCollection()) {
                Horario oldIDHorarioOfMeseroCollectionMesero = meseroCollectionMesero.getIDHorario();
                meseroCollectionMesero.setIDHorario(horario);
                meseroCollectionMesero = em.merge(meseroCollectionMesero);
                if (oldIDHorarioOfMeseroCollectionMesero != null) {
                    oldIDHorarioOfMeseroCollectionMesero.getMeseroCollection().remove(meseroCollectionMesero);
                    oldIDHorarioOfMeseroCollectionMesero = em.merge(oldIDHorarioOfMeseroCollectionMesero);
                }
            }
            for (Cocinero cocineroCollectionCocinero : horario.getCocineroCollection()) {
                Horario oldIDHorarioOfCocineroCollectionCocinero = cocineroCollectionCocinero.getIDHorario();
                cocineroCollectionCocinero.setIDHorario(horario);
                cocineroCollectionCocinero = em.merge(cocineroCollectionCocinero);
                if (oldIDHorarioOfCocineroCollectionCocinero != null) {
                    oldIDHorarioOfCocineroCollectionCocinero.getCocineroCollection().remove(cocineroCollectionCocinero);
                    oldIDHorarioOfCocineroCollectionCocinero = em.merge(oldIDHorarioOfCocineroCollectionCocinero);
                }
            }
            for (Cajero cajeroCollectionCajero : horario.getCajeroCollection()) {
                Horario oldIDHorarioOfCajeroCollectionCajero = cajeroCollectionCajero.getIDHorario();
                cajeroCollectionCajero.setIDHorario(horario);
                cajeroCollectionCajero = em.merge(cajeroCollectionCajero);
                if (oldIDHorarioOfCajeroCollectionCajero != null) {
                    oldIDHorarioOfCajeroCollectionCajero.getCajeroCollection().remove(cajeroCollectionCajero);
                    oldIDHorarioOfCajeroCollectionCajero = em.merge(oldIDHorarioOfCajeroCollectionCajero);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findHorario(horario.getIDHorario()) != null) {
                throw new PreexistingEntityException("Horario " + horario + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Horario horario) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Horario persistentHorario = em.find(Horario.class, horario.getIDHorario());
            Collection<Mesero> meseroCollectionOld = persistentHorario.getMeseroCollection();
            Collection<Mesero> meseroCollectionNew = horario.getMeseroCollection();
            Collection<Cocinero> cocineroCollectionOld = persistentHorario.getCocineroCollection();
            Collection<Cocinero> cocineroCollectionNew = horario.getCocineroCollection();
            Collection<Cajero> cajeroCollectionOld = persistentHorario.getCajeroCollection();
            Collection<Cajero> cajeroCollectionNew = horario.getCajeroCollection();
            Collection<Mesero> attachedMeseroCollectionNew = new ArrayList<Mesero>();
            for (Mesero meseroCollectionNewMeseroToAttach : meseroCollectionNew) {
                meseroCollectionNewMeseroToAttach = em.getReference(meseroCollectionNewMeseroToAttach.getClass(), meseroCollectionNewMeseroToAttach.getIDMesero());
                attachedMeseroCollectionNew.add(meseroCollectionNewMeseroToAttach);
            }
            meseroCollectionNew = attachedMeseroCollectionNew;
            horario.setMeseroCollection(meseroCollectionNew);
            Collection<Cocinero> attachedCocineroCollectionNew = new ArrayList<Cocinero>();
            for (Cocinero cocineroCollectionNewCocineroToAttach : cocineroCollectionNew) {
                cocineroCollectionNewCocineroToAttach = em.getReference(cocineroCollectionNewCocineroToAttach.getClass(), cocineroCollectionNewCocineroToAttach.getIDCocinero());
                attachedCocineroCollectionNew.add(cocineroCollectionNewCocineroToAttach);
            }
            cocineroCollectionNew = attachedCocineroCollectionNew;
            horario.setCocineroCollection(cocineroCollectionNew);
            Collection<Cajero> attachedCajeroCollectionNew = new ArrayList<Cajero>();
            for (Cajero cajeroCollectionNewCajeroToAttach : cajeroCollectionNew) {
                cajeroCollectionNewCajeroToAttach = em.getReference(cajeroCollectionNewCajeroToAttach.getClass(), cajeroCollectionNewCajeroToAttach.getIDCajero());
                attachedCajeroCollectionNew.add(cajeroCollectionNewCajeroToAttach);
            }
            cajeroCollectionNew = attachedCajeroCollectionNew;
            horario.setCajeroCollection(cajeroCollectionNew);
            horario = em.merge(horario);
            for (Mesero meseroCollectionOldMesero : meseroCollectionOld) {
                if (!meseroCollectionNew.contains(meseroCollectionOldMesero)) {
                    meseroCollectionOldMesero.setIDHorario(null);
                    meseroCollectionOldMesero = em.merge(meseroCollectionOldMesero);
                }
            }
            for (Mesero meseroCollectionNewMesero : meseroCollectionNew) {
                if (!meseroCollectionOld.contains(meseroCollectionNewMesero)) {
                    Horario oldIDHorarioOfMeseroCollectionNewMesero = meseroCollectionNewMesero.getIDHorario();
                    meseroCollectionNewMesero.setIDHorario(horario);
                    meseroCollectionNewMesero = em.merge(meseroCollectionNewMesero);
                    if (oldIDHorarioOfMeseroCollectionNewMesero != null && !oldIDHorarioOfMeseroCollectionNewMesero.equals(horario)) {
                        oldIDHorarioOfMeseroCollectionNewMesero.getMeseroCollection().remove(meseroCollectionNewMesero);
                        oldIDHorarioOfMeseroCollectionNewMesero = em.merge(oldIDHorarioOfMeseroCollectionNewMesero);
                    }
                }
            }
            for (Cocinero cocineroCollectionOldCocinero : cocineroCollectionOld) {
                if (!cocineroCollectionNew.contains(cocineroCollectionOldCocinero)) {
                    cocineroCollectionOldCocinero.setIDHorario(null);
                    cocineroCollectionOldCocinero = em.merge(cocineroCollectionOldCocinero);
                }
            }
            for (Cocinero cocineroCollectionNewCocinero : cocineroCollectionNew) {
                if (!cocineroCollectionOld.contains(cocineroCollectionNewCocinero)) {
                    Horario oldIDHorarioOfCocineroCollectionNewCocinero = cocineroCollectionNewCocinero.getIDHorario();
                    cocineroCollectionNewCocinero.setIDHorario(horario);
                    cocineroCollectionNewCocinero = em.merge(cocineroCollectionNewCocinero);
                    if (oldIDHorarioOfCocineroCollectionNewCocinero != null && !oldIDHorarioOfCocineroCollectionNewCocinero.equals(horario)) {
                        oldIDHorarioOfCocineroCollectionNewCocinero.getCocineroCollection().remove(cocineroCollectionNewCocinero);
                        oldIDHorarioOfCocineroCollectionNewCocinero = em.merge(oldIDHorarioOfCocineroCollectionNewCocinero);
                    }
                }
            }
            for (Cajero cajeroCollectionOldCajero : cajeroCollectionOld) {
                if (!cajeroCollectionNew.contains(cajeroCollectionOldCajero)) {
                    cajeroCollectionOldCajero.setIDHorario(null);
                    cajeroCollectionOldCajero = em.merge(cajeroCollectionOldCajero);
                }
            }
            for (Cajero cajeroCollectionNewCajero : cajeroCollectionNew) {
                if (!cajeroCollectionOld.contains(cajeroCollectionNewCajero)) {
                    Horario oldIDHorarioOfCajeroCollectionNewCajero = cajeroCollectionNewCajero.getIDHorario();
                    cajeroCollectionNewCajero.setIDHorario(horario);
                    cajeroCollectionNewCajero = em.merge(cajeroCollectionNewCajero);
                    if (oldIDHorarioOfCajeroCollectionNewCajero != null && !oldIDHorarioOfCajeroCollectionNewCajero.equals(horario)) {
                        oldIDHorarioOfCajeroCollectionNewCajero.getCajeroCollection().remove(cajeroCollectionNewCajero);
                        oldIDHorarioOfCajeroCollectionNewCajero = em.merge(oldIDHorarioOfCajeroCollectionNewCajero);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = horario.getIDHorario();
                if (findHorario(id) == null) {
                    throw new NonexistentEntityException("The horario with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Horario horario;
            try {
                horario = em.getReference(Horario.class, id);
                horario.getIDHorario();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The horario with id " + id + " no longer exists.", enfe);
            }
            Collection<Mesero> meseroCollection = horario.getMeseroCollection();
            for (Mesero meseroCollectionMesero : meseroCollection) {
                meseroCollectionMesero.setIDHorario(null);
                meseroCollectionMesero = em.merge(meseroCollectionMesero);
            }
            Collection<Cocinero> cocineroCollection = horario.getCocineroCollection();
            for (Cocinero cocineroCollectionCocinero : cocineroCollection) {
                cocineroCollectionCocinero.setIDHorario(null);
                cocineroCollectionCocinero = em.merge(cocineroCollectionCocinero);
            }
            Collection<Cajero> cajeroCollection = horario.getCajeroCollection();
            for (Cajero cajeroCollectionCajero : cajeroCollection) {
                cajeroCollectionCajero.setIDHorario(null);
                cajeroCollectionCajero = em.merge(cajeroCollectionCajero);
            }
            em.remove(horario);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Horario> findHorarioEntities() {
        return findHorarioEntities(true, -1, -1);
    }

    public List<Horario> findHorarioEntities(int maxResults, int firstResult) {
        return findHorarioEntities(false, maxResults, firstResult);
    }

    private List<Horario> findHorarioEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Horario.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Horario findHorario(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Horario.class, id);
        } finally {
            em.close();
        }
    }

    public int getHorarioCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Horario> rt = cq.from(Horario.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
