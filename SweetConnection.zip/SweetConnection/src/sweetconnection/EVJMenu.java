package sweetconnection;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;


public class EVJMenu implements Initializable {

    @FXML private Button btnBackLogin;
    
    Ventanas ventana = new Ventanas();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }  
    
    public void backLogin(){
            Image imagenAlert = new Image(getClass().getResourceAsStream("/icons8-game-controller.png"));
            Alert dialogo = new Alert(Alert.AlertType.CONFIRMATION);
            dialogo.setGraphic(new ImageView(imagenAlert));
            Stage escena = (Stage) dialogo.getDialogPane().getScene().getWindow();
            escena.getIcons().add(new Image(this.getClass().getResource("/icons8-game-controller.png").toString()));            
            dialogo.setTitle("Advertencia");
            dialogo.setHeaderText("Cerrar sesión");
            dialogo.setContentText("¿Estás seguro de cerrar sesión?");
            Optional<ButtonType> respuesta = dialogo.showAndWait();
            if (respuesta.get() == ButtonType.OK) {
                escena.close();
                ventana.iniciarLogin();
            }    
    }
    
}
