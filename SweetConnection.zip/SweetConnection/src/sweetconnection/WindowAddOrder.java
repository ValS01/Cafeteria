/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sweetconnection;

import controllers.MeseroJpaController;
import controllers.OrdenJpaController;
import controllers.PlatilloJpaController;
import entities.Mesero;
import entities.Orden;
import entities.Platillo;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;

public class WindowAddOrder implements Initializable {   

    Ventanas ven = new Ventanas();
    
    
    @FXML private Button btnAdd;
    @FXML private Button btnCancel;
    
    //Botones de los productos
    //CupCake
    @FXML private Button btnCC;
    //Malteada de mando
    @FXML private Button btnMdM;
    //Sandwich de queso
    @FXML private Button btnSdQ;
    //Sandwich de jamon
    @FXML private Button btnSdJ;
    //CupCake de chocolate
    @FXML private Button btnCCdC;
    //Pay de jamon
    @FXML private Button btnPdJ;
    //Pastel de reese's
    @FXML private Button btnPdR;
    //Niño envuelto dulce
    @FXML private Button btnNED;
    
    private OrdenJpaController OJC;
    private PlatilloJpaController PJC;
    private MeseroJpaController MJC;
    
    private int lastOrder;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {        
        OJC = new OrdenJpaController();
        PJC = new PlatilloJpaController();
        MJC = new MeseroJpaController();
    }    
    
    public int obtenerSiguienteOrden() throws Exception{
        lastOrder = OJC.getOrdenCount();
        return lastOrder;
    }
    
    public void agregarOrden() throws Exception{                  
        
    }
    
    public void backWaiter() throws Exception{
        ven.menuMesero();
    }
    
    
    
}

