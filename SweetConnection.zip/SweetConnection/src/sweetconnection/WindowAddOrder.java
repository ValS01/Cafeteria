/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sweetconnection;

import controllers.MeseroJpaController;
import controllers.OrdenJpaController;
import controllers.PlatilloJpaController;
import entities.Mesero;
import entities.Orden;
import entities.Platillo;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;

public class WindowAddOrder implements Initializable {   

    Ventanas ven = new Ventanas();
    
    @FXML private TextArea boxText;
    @FXML private Button btnAdd;
    @FXML private Button btnCancel;
    
    @FXML private Label lbNoOrden;
    
    private OrdenJpaController OJC;
    private PlatilloJpaController PJC;
    private MeseroJpaController MJC;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {        
        OJC = new OrdenJpaController();
        PJC = new PlatilloJpaController();
        MJC = new MeseroJpaController();
    }    
    
    public void agregarOrden() throws Exception{
        String ordenCompleta = boxText.getText();
        StringTokenizer st = new StringTokenizer(ordenCompleta,", ",true);
        //String[] parts = ordenCompleta.split(", ");
        int contPlatillo = 0;
        while(st.hasMoreTokens()){            
            String numOrden = st.nextToken(); // identificador de la orden
            st.nextToken();
            st.nextToken();
            String ID_platillo = st.nextToken(); // identificador del platillo
            st.nextToken();
            st.nextToken();
            String ID_mesero = st.nextToken();            
            
            int iNumOrden = Integer.valueOf(numOrden);
            
            System.out.println(numOrden);
            System.out.println(ID_platillo);
            System.out.println(ID_mesero);
            
            Orden newOrden = new Orden();
            
            Platillo pla = PJC.findPlatillo(ID_platillo);            
            System.out.println(pla);
            
            Mesero mes = MJC.findMesero(ID_mesero);
            System.out.println(mes);
            
            newOrden.setNumOrden(iNumOrden);
            newOrden.setIDPlatillo(pla);
            newOrden.setIDMesero(mes);
            
            OJC.create(newOrden);
            
            //contPlatillo+=3;
            
        }
        ven.menuMesero();
    }
    
    public void backWaiter() throws Exception{
        ven.menuMesero();
    }
    
    
    
}

