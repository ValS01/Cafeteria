/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sweetconnection;

import controllers.OrdenJpaController;
import entities.Orden;
import entities.Platillo;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class WindowShowOrder implements Initializable {

    @FXML private Button btnBack;
    @FXML private Button btnOrderTable;
    @FXML private Button btnEliminar;
    
    
    @FXML private TableColumn<Orden,Number> clmnIdOrden;
    @FXML private TableColumn<Orden,Platillo> clmnPlatillo;
    
    @FXML private TableView<Orden> tblViewOrden;
    
    private ObservableList<Orden> listaOrdenes;    
    
    
    private OrdenJpaController OJC;
    
    Ventanas ven = new Ventanas();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {        
        OJC = new OrdenJpaController();       
        
        listaOrdenes = FXCollections.observableArrayList(OJC.findOrdenEntities());        
        System.out.println(listaOrdenes);
        tblViewOrden.setItems(listaOrdenes);
        
        /*Platillo plt = listaOrdenes.get(0).getIDPlatillo();
        System.out.println(plt.getNombrePlatillo());*/
        
        
        clmnIdOrden.setCellValueFactory(new PropertyValueFactory<Orden,Number>("NumOrden"));
        clmnPlatillo.setCellValueFactory(new PropertyValueFactory<Orden,Platillo>("ID_Platillo"));        
    }    
    
    public void backTableOcu() throws Exception{
        ven.menuMesero();
    }
    
    public void ordenPorMesa() throws Exception{
        
    }
    
    public void eliminarOrden() throws Exception {
        OJC = new OrdenJpaController();  
        int value = tblViewOrden.getSelectionModel().getSelectedItem().getNumOrden();
        OJC.destroy(value);
        
    }
    
}
