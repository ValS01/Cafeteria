package sweetconnection;

import controllers.CajeroJpaController;
import controllers.CocineroJpaController;
import controllers.MesameseroonJpaController;
import controllers.MeseroJpaController;
import entities.Mesameseroon;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class WindowLogin implements Initializable {

    @FXML private TextField tfUsuario;
    @FXML private PasswordField tfContra;
    
    @FXML private Button btnIngresar;
    
    private CocineroJpaController COJC;
    private CajeroJpaController CAJC;
    private MeseroJpaController MJC;
    private MesameseroonJpaController MMJP;
    
    private boolean res=false;
            
    private Ventanas vent = new Ventanas();
    
    @Override
    public void initialize(URL url, ResourceBundle rb){
        COJC = new CocineroJpaController();
        CAJC = new CajeroJpaController();
        MJC = new MeseroJpaController();
        MMJP = new MesameseroonJpaController();
    }               
    
    public String definirUsuario(){
        String userNoDefinido = tfUsuario.getText();
        String userDefinido = userNoDefinido.substring(0, 4); 
        return userDefinido;
    }
    
    public boolean buscarMesero(){
        String idMesero = tfUsuario.getText();
        String contraMe = tfContra.getText();
        if(MJC.findMesero(idMesero).getIDMesero().equals(idMesero)
                && MJC.findMesero(idMesero).getContrasenia().equals(contraMe)){
            res = true;
        }else{
            res = false;
        }
        return res;
    }
    
    public boolean buscarCajero(){
        String idCajero = tfUsuario.getText();
        String contraCa = tfContra.getText();
        if(CAJC.findCajero(idCajero).getIDCajero().equals(idCajero)
                && CAJC.findCajero(idCajero).getContrasenia().equals(contraCa)){
            res = true;
        }else{
            res = false;
        }
        return res;
    }
    
    public boolean buscarCocinero(){
        String idCocinero = tfUsuario.getText();
        String contraCo = tfContra.getText();
        if(COJC.findCocinero(idCocinero).getIDCocinero().equals(idCocinero)
                && COJC.findCocinero(idCocinero).getContrasenia().equals(contraCo)){
            res = true;
        }else{
            res = false;
        }
        return res;
    }
    
    public void iniciarUsuario(){
        try{
            String userActual = definirUsuario();                             
            if(tfUsuario.getText().equals("ADMIN") && tfContra.getText().equals("54321")){
                vent.menuAdmin();
            }else if(userActual.equals("Mese")){
                boolean resValidacionM = buscarMesero();
                if(resValidacionM==true){
                    Mesameseroon mmon = new Mesameseroon();
                    mmon.setContador(1);
                    mmon.setIDMesero(tfUsuario.getText());
                    MMJP.create(mmon);
                    vent.menuMesero();
                }else{
                    Image imagenAlert = new Image(getClass().getResourceAsStream("/images/icons8-requisition-64.png"));
                    Alert dialogo = new Alert(Alert.AlertType.ERROR);
                    dialogo.setGraphic(new ImageView(imagenAlert));
                    Stage escena = (Stage) dialogo.getDialogPane().getScene().getWindow();
                    escena.getIcons().add(new Image(this.getClass().getResource("/images/icons8-requisition-64.png").toString()));            
                    dialogo.setTitle("Advertencia");
                    dialogo.setHeaderText("Usuario o contraseña del Mesero incorrectos");
                    dialogo.setContentText("Vuelve a intentar Mesero");
                    Optional<ButtonType> respuesta = dialogo.showAndWait(); 
                }
            }else if(userActual.equals("Caje")){
                boolean resValidacionCA = buscarCajero();
                if(resValidacionCA==true){
                    vent.menuCashier();
                }else{
                    Image imagenAlert = new Image(getClass().getResourceAsStream("/images/icons8-requisition-64.png"));
                    Alert dialogo = new Alert(Alert.AlertType.ERROR);
                    dialogo.setGraphic(new ImageView(imagenAlert));
                    Stage escena = (Stage) dialogo.getDialogPane().getScene().getWindow();
                    escena.getIcons().add(new Image(this.getClass().getResource("/images/icons8-requisition-64.png").toString()));            
                    dialogo.setTitle("Advertencia");
                    dialogo.setHeaderText("Usuario o contraseña del Cajero incorrectos");
                    dialogo.setContentText("Vuelve a intentar Cajero");
                    Optional<ButtonType> respuesta = dialogo.showAndWait(); 
                }
            }else if(userActual.equals("Coci")){
                boolean resValidacionCO = buscarCocinero();
                if(resValidacionCO==true){
                    vent.menuChef();
                }else{               
                    Image imagenAlert = new Image(getClass().getResourceAsStream("/images/icons8-requisition-64.png"));
                    Alert dialogo = new Alert(Alert.AlertType.ERROR);
                    dialogo.setGraphic(new ImageView(imagenAlert));
                    Stage escena = (Stage) dialogo.getDialogPane().getScene().getWindow();
                    escena.getIcons().add(new Image(this.getClass().getResource("/images/icons8-requisition-64.png").toString()));            
                    dialogo.setTitle("Advertencia");
                    dialogo.setHeaderText("Usuario o contraseña del Cocinero");
                    dialogo.setContentText("Vuelve a intentar Cocinero");
                    Optional<ButtonType> respuesta = dialogo.showAndWait(); 
                }
            }else{
                Image imagenAlert = new Image(getClass().getResourceAsStream("/images/icons8-requisition-64.png"));
                Alert dialogo = new Alert(Alert.AlertType.ERROR);
                dialogo.setGraphic(new ImageView(imagenAlert));
                Stage escena = (Stage) dialogo.getDialogPane().getScene().getWindow();
                escena.getIcons().add(new Image(this.getClass().getResource("/images/icons8-requisition-64.png").toString()));            
                dialogo.setTitle("Advertencia");
                dialogo.setHeaderText("Usuario o contraseña no validos");
                dialogo.setContentText("Vuelve a intentar");
                Optional<ButtonType> respuesta = dialogo.showAndWait();                
            }            
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
}
