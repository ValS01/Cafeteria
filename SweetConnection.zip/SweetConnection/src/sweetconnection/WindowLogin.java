package sweetconnection;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class WindowLogin implements Initializable {

    @FXML private ImageView imgWaitress;
    @FXML private ImageView imgCashier;
    @FXML private ImageView imgChef;
    @FXML private ImageView imgAdmin;
    
    
    
    
    private Ventanas ventana = new Ventanas();
    
    @Override
    public void initialize(URL url, ResourceBundle rb){
        
    }    
    
    
    public void menuMesero(){
        try{
            ventana.menuMesero();
               
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void menuCajero(){
        try{
            ventana.menuCashier();
               
        }catch(Exception e){
            System.out.println(e);
        }
    }    
    
    public void menuCocinero(){
        try{
            ventana.menuChef();
               
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void menuAdministrador(){
        try{
            ventana.menuAdmin();
               
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
}
