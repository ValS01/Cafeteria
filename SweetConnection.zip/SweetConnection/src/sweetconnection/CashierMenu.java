/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sweetconnection;

import controllers.OrdenJpaController;
import java.net.URL;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCombination;
import javafx.stage.Stage;

public class CashierMenu implements Initializable {

    @FXML private Button btnBackLogin;
    
    @FXML private ImageView mesa1;
    @FXML private ImageView mesa2;
    @FXML private ImageView mesa3;
    @FXML private ImageView mesa4;
    @FXML private ImageView mesa5;
    @FXML private ImageView mesa6;
    @FXML private ImageView mesa7;
    @FXML private ImageView mesa8;
    
    @FXML private DatePicker tpDiaActual;
    
    Ventanas ventana = new Ventanas();
    
    @FXML private Button btnCalcular;
    
    private OrdenJpaController OJC;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {     
        tpDiaActual = new DatePicker();        
    } 
    
    public void registroDeHoy(){        
        tpDiaActual.setValue(LocalDate.MAX);
        tpDiaActual.setEditable(false);
        
        int numVentas = OJC.getOrdenCount();        
        
    }
    
    public void regresarLogin(){        
            Image imagenAlert = new Image(getClass().getResourceAsStream("/icons8-cash-register.png"));
            Alert dialogo = new Alert(Alert.AlertType.CONFIRMATION);
            dialogo.setGraphic(new ImageView(imagenAlert));
            Stage escena = (Stage) dialogo.getDialogPane().getScene().getWindow();
            escena.getIcons().add(new Image(this.getClass().getResource("/icons8-cash-register.png").toString()));            
            dialogo.setTitle("Advertencia");
            dialogo.setHeaderText("Cerrar sesión");
            dialogo.setContentText("¿Estás seguro de cerrar sesión?");
            Optional<ButtonType> respuesta = dialogo.showAndWait();
            if (respuesta.get() == ButtonType.OK) {
                ventana.iniciarLogin();
            }            
    }
    
    public void windowVenta() throws Exception{
        ventana.ventanaPagar();
    }
    
}
