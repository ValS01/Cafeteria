package sweetconnection;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class SweetConnection extends Application {
    
    private Stage primaryStage;
    
    Ventanas ventana= new Ventanas();
	
    public void start(Stage primaryStage) throws Exception {
	ventana.iniciarLogin();
    }

    public Stage getPrimaryStage() {
        return primaryStage;
        }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
