/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sweetconnection;

import controllers.IngredientesJpaController;
import controllers.OrdenJpaController;
import entities.Ingredientes;
import entities.Orden;
import entities.Platillo;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;


public class ChefMenu implements Initializable {

    @FXML private Button btnBackLogin;
    
    @FXML private Button btnNext;
    
    @FXML private Button btnUpdate;
    @FXML private Button btnDelete;
    @FXML private Button btnAdd;
    
    @FXML private TextArea taOrdenes;
    
    @FXML private Label lbnOrden;
    
    @FXML private TableView<Ingredientes> tblViewIngredientes;     
    private ObservableList<Ingredientes> listIngredientes;        
    
    @FXML private TableColumn<Ingredientes,String> clmnIdIngrediente;
    @FXML private TableColumn<Ingredientes,String> clmnNomIngrediente;
    @FXML private TableColumn<Ingredientes,String> clmnCaducidad;
    @FXML private TableColumn<Ingredientes,Number> clmnCantidad;
    
    Ventanas ventana = new Ventanas();
    
    private List<Orden> listaOrderChef;   
        
    private IngredientesJpaController IJC;
    private OrdenJpaController OJC;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        IJC = new IngredientesJpaController();
        OJC = new OrdenJpaController();
        
        taOrdenes = new TextArea();
        lbnOrden = new Label();        
        
        listaOrderChef = new ArrayList<Orden>();
        listaOrderChef = OJC.findOrdenEntities();
        
        for(int i = 0; i<listaOrderChef.size(); i++){
            lbnOrden.setText(String.valueOf(listaOrderChef.get(i).getNumOrden()));
            int numOrder = listaOrderChef.get(i).getNumOrden();
            Platillo plat = listaOrderChef.get(i).getIDPlatillo();
            //String sNumOrder = String.valueOf(i);
            taOrdenes.appendText(i + ".- "+ plat.getNombrePlatillo()+"\n");
            System.out.println(i + ".- "+ plat.getNombrePlatillo());
        }
        
        listIngredientes = FXCollections.observableArrayList(IJC.findIngredientesEntities());
        tblViewIngredientes.setItems(listIngredientes);
        System.out.println(listIngredientes);
              
        clmnIdIngrediente.setCellValueFactory(new PropertyValueFactory<Ingredientes,String>("ID_Ingrediente"));
        clmnNomIngrediente.setCellValueFactory(new PropertyValueFactory<Ingredientes,String>("NomIngrediente"));
        clmnCaducidad.setCellValueFactory(new PropertyValueFactory<Ingredientes,String>("Caducidad"));
        clmnCantidad.setCellValueFactory(new PropertyValueFactory<Ingredientes,Number>("Cantidad"));
    }  
    
    public void mostrarPlatillo(){
        OJC = new OrdenJpaController();
        taOrdenes = new TextArea();
        lbnOrden = new Label();
        listaOrderChef = new ArrayList<Orden>();
        listaOrderChef = OJC.findOrdenEntities();        
        for(int i = 0; i<listaOrderChef.size(); i++){
            lbnOrden.setText(String.valueOf(listaOrderChef.get(i).getNumOrden()));
            int numOrder = listaOrderChef.get(i).getNumOrden();
            Platillo plat = listaOrderChef.get(i).getIDPlatillo();
            //String sNumOrder = String.valueOf(i);
            taOrdenes.appendText(i + ".- "+ plat.getNombrePlatillo()+"\n");
            System.out.println(i + ".- "+ plat.getNombrePlatillo());
        }
    }
    
    public void backLogin(){
        Image imagenAlert = new Image(getClass().getResourceAsStream("/icons8-chef-hat.png"));
            Alert dialogo = new Alert(Alert.AlertType.CONFIRMATION);
            dialogo.setGraphic(new ImageView(imagenAlert));
            Stage escena = (Stage) dialogo.getDialogPane().getScene().getWindow();
            escena.getIcons().add(new Image(this.getClass().getResource("/icons8-chef-hat.png").toString()));            
            dialogo.setTitle("Advertencia");
            dialogo.setHeaderText("Cerrar sesión");
            dialogo.setContentText("¿Estás seguro de cerrar sesión?");
            Optional<ButtonType> respuesta = dialogo.showAndWait();
            if (respuesta.get() == ButtonType.OK) {
                ventana.iniciarLogin();
            }    
    }
    
    public void windowAddIngrediente()throws Exception{
        ventana.ventanaAddIngre();
    }
    
    public void windowUpdateIngrediente()throws Exception{
        ventana.ventanaUpdateIngre();
    }
    
    public void deleteIngre(){
        
    }
}
