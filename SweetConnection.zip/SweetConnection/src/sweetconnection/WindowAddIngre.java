/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sweetconnection;

import controllers.IngredientesJpaController;
import entities.Ingredientes;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class WindowAddIngre implements Initializable {

    @FXML private Button btnBack;
    
    @FXML private Button btnAdd;
    @FXML private Button btnUp;
    
    @FXML private TextField idIngre;
    @FXML private TextField nomIngre;
    @FXML private TextField caducidad;
    @FXML private TextField cantidad;
    
    
    Ventanas ven = new Ventanas();
    
    private IngredientesJpaController IJC;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        IJC = new IngredientesJpaController();
    }        
    public void backChefMenu() throws Exception{
        ven.menuChef();
    }    
    public void addIngrediente()throws Exception{
        Ingredientes ingre = new Ingredientes();
        ingre.setIDIngrediente(idIngre.getText());
        ingre.setNomIngrediente(nomIngre.getText());
        ingre.setCaducidad(caducidad.getText());
        ingre.setCantidad(Integer.valueOf(cantidad.getText()));
        IJC.create(ingre);
        ven.menuChef();
    }       
}

