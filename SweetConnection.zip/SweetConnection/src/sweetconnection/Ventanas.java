package sweetconnection;


import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.SubScene;
import javafx.scene.control.Dialog;
import javafx.scene.control.TabPane;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class Ventanas {
    
    private static Stage st= new Stage();
    Image ico[] = new Image[1];
    
    
    public void iniciarLogin(){
        try {
		HBox root = (HBox)FXMLLoader.load(getClass().getResource("window_login.fxml"));
		Scene scene = new Scene(root);
		//scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());			
                st.setScene(scene);
                st.setTitle("INICIAR SESIÓN");
		st.show();
                ico[0] = new Image("images/mainLogo.png");
                st.getIcons().add(ico[0]);
                
		} catch(Exception e) {
			e.printStackTrace();
	}
    }
    
    public void menuMesero() throws Exception{
        //Timeline timeline = new Timeline();
        BorderPane pane = (BorderPane)FXMLLoader.load(getClass().getResource("waiter_menu.fxml"));                                  
        st.setTitle("MENU MESERO");            
        ico[0] = new Image("images/mainLogo.png");
        st.getIcons().add(ico[0]);
        Scene scene = new Scene(pane);
        st.setScene(scene);
        st.show();       
        
    }
    
    public void menuAdmin() throws Exception{
        BorderPane pane = (BorderPane) FXMLLoader.load(getClass().getResource("admin_menu.fxml"));
        st.setTitle("MENU ADMINISTRADOR");
        ico[0] = new Image("images/mainLogo.png");
        st.getIcons().add(ico[0]);
        Scene scene = new Scene(pane);
        st.setScene(scene);
        st.show();
    }
    
    public void menuCashier() throws Exception{
        BorderPane pane = (BorderPane) FXMLLoader.load(getClass().getResource("cashier_menu.fxml"));
        st.setTitle("MENU CAJERO");
        ico[0] = new Image("images/mainLogo.png");
        st.getIcons().add(ico[0]);
        Scene scene = new Scene(pane);
        st.setScene(scene);
        st.show();
    }
    
    public void menuChef() throws Exception{
        BorderPane pane = (BorderPane) FXMLLoader.load(getClass().getResource("chef_menu.fxml"));
        st.setTitle("MENU COCINERO");
        ico[0] = new Image("images/mainLogo.png");
        st.getIcons().add(ico[0]);
        Scene scene = new Scene(pane);
        st.setScene(scene);
        st.show();
    }
    
    public void venAddOrder() throws Exception{
        AnchorPane pane = (AnchorPane) FXMLLoader.load(getClass().getResource("window_add_order.fxml"));
        st.setTitle("Agregar orden");
        ico[0] = new Image("images/mainLogo.png");
        st.getIcons().add(ico[0]);
        Scene scene = new Scene(pane);
        st.setScene(scene);
        st.show();
    }
    
    public void venShowOrder() throws Exception{
        BorderPane pane = (BorderPane) FXMLLoader.load(getClass().getResource("window_show_order.fxml"));
        st.setTitle("Mostrar orden");
        ico[0] = new Image("images/mainLogo.png");
        st.getIcons().add(ico[0]);
        Scene scene = new Scene(pane);
        st.setScene(scene);
        st.show();
    }
    
    public void ventanaPagar() throws Exception{
        AnchorPane pane = (AnchorPane) FXMLLoader.load(getClass().getResource("pay_window.fxml"));
        st.setTitle("Mostrar orden");
        ico[0] = new Image("images/mainLogo.png");
        st.getIcons().add(ico[0]);
        Scene scene = new Scene(pane);
        st.setScene(scene);
        st.show();
    }
    
    public void ventanaAddIngre() throws Exception{
        AnchorPane pane = (AnchorPane) FXMLLoader.load(getClass().getResource("window_add_ingre.fxml"));
        st.setTitle("Mostrar orden");
        ico[0] = new Image("images/mainLogo.png");
        st.getIcons().add(ico[0]);
        Scene scene = new Scene(pane);
        st.setScene(scene);
        st.show();
    }
    
    public void ventanaUpdateIngre() throws Exception{
        AnchorPane pane = (AnchorPane) FXMLLoader.load(getClass().getResource("window_upd_ingre.fxml"));
        st.setTitle("Mostrar orden");
        ico[0] = new Image("images/mainLogo.png");
        st.getIcons().add(ico[0]);
        Scene scene = new Scene(pane);
        st.setScene(scene);
        st.show();
    }
    
    public void ventanaVerificarUsurio() throws Exception{
        Pane pane = (Pane) FXMLLoader.load(getClass().getResource("loggeo_user.fxml"));
        st.setTitle("verificar usuario");
        ico[0] = new Image("images/mainLogo.png");
        st.getIcons().add(ico[0]);
        Scene scene = new Scene(pane);
        st.setScene(scene);
        st.show();
    }
}
