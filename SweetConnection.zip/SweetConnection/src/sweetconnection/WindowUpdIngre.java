/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sweetconnection;

import controllers.IngredientesJpaController;
import entities.Ingredientes;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class WindowUpdIngre implements Initializable {

    @FXML Button btnBack; 
    
    Ventanas ven = new Ventanas();
    
    @FXML private Button btnUpd;
    
    
    @FXML private TextField idIngreU;
    @FXML private TextField nomIngreU;
    @FXML private TextField caducidadU;
    @FXML private TextField cantidadU;
    
    private IngredientesJpaController IJC;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        IJC = new IngredientesJpaController();
    }    
    
    public void backMenuChef() throws Exception{
        ven.menuChef();
    }
    public void updIngrediente() throws Exception{
        Ingredientes ingre = new Ingredientes();
        ingre.setIDIngrediente(idIngreU.getText());
        ingre.setNomIngrediente(nomIngreU.getText());
        ingre.setCaducidad(caducidadU.getText());
        ingre.setCantidad(Integer.valueOf(cantidadU.getText()));
        System.out.println(ingre);
        IJC.edit(ingre);
        ven.menuChef();
    }
}
