/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sweetconnection;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCombination;
import javafx.stage.Stage;

public class WaiterMenu implements Initializable {

    @FXML private Button btnClose;
    @FXML private ImageView table1;
    @FXML private ImageView table2;
    @FXML private ImageView table3;
    @FXML private ImageView table4;
    @FXML private ImageView table5;
    @FXML private ImageView table6;
    @FXML private ImageView table7;
    @FXML private ImageView table8;
    
    @FXML private ImageView table1ocu;
    @FXML private ImageView table2ocu;
    @FXML private ImageView table3ocu;
    @FXML private ImageView table4ocu;
    @FXML private ImageView table5ocu;
    @FXML private ImageView table6ocu;
    @FXML private ImageView table7ocu;
    @FXML private ImageView table8ocu;    
        
    Ventanas ventana = new Ventanas();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {     
        
    }        
    
    public void regresarLogin(){        
            Image imagenAlert = new Image(getClass().getResourceAsStream("/icons8-waiter.png"));
            Alert dialogo = new Alert(Alert.AlertType.CONFIRMATION);
            dialogo.setGraphic(new ImageView(imagenAlert));
            Stage escena = (Stage) dialogo.getDialogPane().getScene().getWindow();
            escena.getIcons().add(new Image(this.getClass().getResource("/icons8-waiter.png").toString()));            
            dialogo.setTitle("Advertencia");
            dialogo.setHeaderText("Cerrar sesión");
            dialogo.setContentText("¿Estás seguro de cerrar sesión?");
            Optional<ButtonType> respuesta = dialogo.showAndWait();
            if (respuesta.get() == ButtonType.OK) {                
                ventana.iniciarLogin();
            }            
    }
    
    public void venAddOrder() throws Exception{
        ventana.venAddOrder();
    }
    
    public void venShowOrder() throws Exception{
        ventana.venShowOrder();
    }
}
