/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sweetconnection;

import controllers.CajeroJpaController;
import controllers.CocineroJpaController;
import controllers.HorarioJpaController;
import controllers.MeseroJpaController;
import controllers.OrdenJpaController;
import controllers.PlatilloJpaController;
import entities.Cajero;
import entities.Cocinero;
import entities.Horario;
import entities.Mesero;
import entities.Orden;
import entities.Platillo;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;


public class AdministratorMenu implements Initializable {
        
    @FXML private Button btnBackLogin;
    @FXML private Button btnAdd;
    
    @FXML private Button btnDel1;    
    @FXML private Button btnDel2;    
    @FXML private Button btnDel3;
    
    @FXML private TextField tfUsuario;
    @FXML private TextField tfNombre;
    @FXML private TextField tfTelefono;
    @FXML private TextField tfContrasena;
    @FXML private TextField tfHorario;
    
    
    //private Horario horario;
    
    private HorarioJpaController HJC;
    
    Ventanas ventana = new Ventanas();
    
    private CocineroJpaController COJC;
    
    @FXML private TableView<Cocinero> tblViewCocinero;    
    @FXML private ObservableList<Cocinero> listaCocineros;   
    
    @FXML private TableColumn<Cocinero,String> clmnIdCocinero;
    @FXML private TableColumn<Cocinero,String> clmnNombreco;
    @FXML private TableColumn<Cocinero,String> clmnTelefonoco;
    @FXML private TableColumn<Cocinero,String> clmnContraseniaco;
    @FXML private TableColumn<Cocinero,String> clmnIdHorarioco;    
    
    private CajeroJpaController CAJC;
    
    @FXML private TableView<Cajero> tblViewCajero;   
    @FXML private ObservableList<Cajero> listaCajeros;   
    
    @FXML private TableColumn<Cajero,String> clmnIdCajero;
    @FXML private TableColumn<Cajero,String> clmnNombreca;
    @FXML private TableColumn<Cajero,String> clmnTelefonoca;
    @FXML private TableColumn<Cajero,String> clmnContraseniaca;
    @FXML private TableColumn<Cajero,String> clmnIdHorarioca;
    
    private MeseroJpaController MJC;
        
    @FXML private TableView<Mesero> tblViewMesero;   
    @FXML private ObservableList<Mesero> listaMeseros;   
    
    @FXML private TableColumn<Mesero,String> clmnIdMesero;
    @FXML private TableColumn<Mesero,String> clmnNombreme;
    @FXML private TableColumn<Mesero,String> clmnTelefonome;
    @FXML private TableColumn<Mesero,String> clmnContraseniame;
    @FXML private TableColumn<Mesero,String> clmnIdHorariome;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        HJC = new HorarioJpaController();
        
        COJC = new CocineroJpaController();               
        listaCocineros = FXCollections.observableArrayList(COJC.findCocineroEntities());        
        tblViewCocinero.setItems(listaCocineros);
        clmnIdCocinero.setCellValueFactory(new PropertyValueFactory<Cocinero,String>("ID_Cocinero"));
        clmnNombreco.setCellValueFactory(new PropertyValueFactory<Cocinero,String>("Nombre"));   
        clmnTelefonoco.setCellValueFactory(new PropertyValueFactory<Cocinero,String>("Telefono"));   
        clmnContraseniaco.setCellValueFactory(new PropertyValueFactory<Cocinero,String>("Contrasenia"));   
        clmnIdHorarioco.setCellValueFactory(new PropertyValueFactory<Cocinero,String>("ID_Horario"));   
        
        CAJC = new CajeroJpaController();               
        listaCajeros = FXCollections.observableArrayList(CAJC.findCajeroEntities());        
        tblViewCajero.setItems(listaCajeros);
        clmnIdCajero.setCellValueFactory(new PropertyValueFactory<Cajero,String>("ID_Cajero"));
        clmnNombreca.setCellValueFactory(new PropertyValueFactory<Cajero,String>("Nombre"));   
        clmnTelefonoca.setCellValueFactory(new PropertyValueFactory<Cajero,String>("Telefono"));   
        clmnContraseniaca.setCellValueFactory(new PropertyValueFactory<Cajero,String>("Contrasenia"));   
        clmnIdHorarioca.setCellValueFactory(new PropertyValueFactory<Cajero,String>("ID_Horario"));
        
        MJC = new MeseroJpaController();               
        listaMeseros = FXCollections.observableArrayList(MJC.findMeseroEntities());        
        tblViewMesero.setItems(listaMeseros);
        clmnIdMesero.setCellValueFactory(new PropertyValueFactory<Mesero,String>("ID_Mesero"));
        clmnNombreme.setCellValueFactory(new PropertyValueFactory<Mesero,String>("Nombre"));   
        clmnTelefonome.setCellValueFactory(new PropertyValueFactory<Mesero,String>("Telefono"));   
        clmnContraseniame.setCellValueFactory(new PropertyValueFactory<Mesero,String>("Contrasenia"));   
        clmnIdHorariome.setCellValueFactory(new PropertyValueFactory<Mesero,String>("ID_Horario"));       
        
    }  
    
    public void backLogin(){
        Image imagenAlert = new Image(getClass().getResourceAsStream("/icons8-manager.png"));
            Alert dialogo = new Alert(Alert.AlertType.CONFIRMATION);
            dialogo.setGraphic(new ImageView(imagenAlert));
            Stage escena = (Stage) dialogo.getDialogPane().getScene().getWindow();
            escena.getIcons().add(new Image(this.getClass().getResource("/icons8-manager.png").toString()));            
            dialogo.setTitle("Advertencia");
            dialogo.setHeaderText("Cerrar sesión");
            dialogo.setContentText("¿Estás seguro de cerrar sesión?");
            Optional<ButtonType> respuesta = dialogo.showAndWait();
            if (respuesta.get() == ButtonType.OK) {
                ventana.iniciarLogin();
            }    
    }
    
    public void addEmpleado()throws Exception{        
        String usuario = tfUsuario.getText();
        String tipoEmpleado = usuario.substring(0, 4);        
        if(tipoEmpleado.equals("Mese")){
            Mesero mesero = new Mesero();           
            
            Horario horario = HJC.findHorario(tfHorario.getText());            
            
            mesero.setIDMesero(tfUsuario.getText());
            mesero.setNombre(tfNombre.getText());
            mesero.setTelefono(tfTelefono.getText());
            mesero.setContrasenia(tfContrasena.getText());            
            mesero.setIDHorario(horario);
            
            MJC.create(mesero);
        }else if(tipoEmpleado.equals("Coci")){
            Cocinero cocinero = new Cocinero();           
            
            Horario horario = HJC.findHorario(tfHorario.getText());            
            
            cocinero.setIDCocinero(tfUsuario.getText());
            cocinero.setNombre(tfNombre.getText());
            cocinero.setTelefono(tfTelefono.getText());
            cocinero.setContrasenia(tfContrasena.getText());            
            cocinero.setIDHorario(horario);
            
            COJC.create(cocinero);
        }else if(tipoEmpleado.equals("Caje")){
            Cajero cajero = new Cajero();           
            
            Horario horario = HJC.findHorario(tfHorario.getText());            
            
            cajero.setIDCajero(tfUsuario.getText());
            cajero.setNombre(tfNombre.getText());
            cajero.setTelefono(tfTelefono.getText());
            cajero.setContrasenia(tfContrasena.getText());            
            cajero.setIDHorario(horario);
            
            CAJC.create(cajero);
        }
    }
    
    public void delMesero()throws Exception{
        String meserodel = tblViewMesero.getSelectionModel().getSelectedItem().getIDMesero();
        MJC.destroy(meserodel);
    }
    public void delCajero() throws Exception{
        String cajerodel = tblViewCajero.getSelectionModel().getSelectedItem().getIDCajero();
        CAJC.destroy(cajerodel);
    }
    public void delCocinero() throws Exception{
        String cocinerodel = tblViewCocinero.getSelectionModel().getSelectedItem().getIDCocinero();        
        COJC.destroy(cocinerodel);
    }  
    
}
