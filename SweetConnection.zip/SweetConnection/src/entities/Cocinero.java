/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author murdo
 */
@Entity
@Table(name = "cocinero")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cocinero.findAll", query = "SELECT c FROM Cocinero c")
    , @NamedQuery(name = "Cocinero.findByIDCocinero", query = "SELECT c FROM Cocinero c WHERE c.iDCocinero = :iDCocinero")
    , @NamedQuery(name = "Cocinero.findByNombre", query = "SELECT c FROM Cocinero c WHERE c.nombre = :nombre")
    , @NamedQuery(name = "Cocinero.findByTelefono", query = "SELECT c FROM Cocinero c WHERE c.telefono = :telefono")
    , @NamedQuery(name = "Cocinero.findByContrasenia", query = "SELECT c FROM Cocinero c WHERE c.contrasenia = :contrasenia")})
public class Cocinero implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID_Cocinero")
    private String iDCocinero;
    @Column(name = "Nombre")
    private String nombre;
    @Column(name = "Telefono")
    private String telefono;
    @Column(name = "Contrasenia")
    private String contrasenia;
    @JoinColumn(name = "ID_Horario", referencedColumnName = "ID_Horario")
    @ManyToOne
    private Horario iDHorario;

    public Cocinero() {
    }

    public Cocinero(String iDCocinero) {
        this.iDCocinero = iDCocinero;
    }

    public String getIDCocinero() {
        return iDCocinero;
    }

    public void setIDCocinero(String iDCocinero) {
        this.iDCocinero = iDCocinero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public Horario getIDHorario() {
        return iDHorario;
    }

    public void setIDHorario(Horario iDHorario) {
        this.iDHorario = iDHorario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDCocinero != null ? iDCocinero.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cocinero)) {
            return false;
        }
        Cocinero other = (Cocinero) object;
        if ((this.iDCocinero == null && other.iDCocinero != null) || (this.iDCocinero != null && !this.iDCocinero.equals(other.iDCocinero))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Cocinero[ iDCocinero=" + iDCocinero + " ]";
    }
    
}
