/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author murdo
 */
@Entity
@Table(name = "mesameseroon")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mesameseroon.findAll", query = "SELECT m FROM Mesameseroon m")
    , @NamedQuery(name = "Mesameseroon.findByContador", query = "SELECT m FROM Mesameseroon m WHERE m.contador = :contador")
    , @NamedQuery(name = "Mesameseroon.findByIDMesa", query = "SELECT m FROM Mesameseroon m WHERE m.iDMesa = :iDMesa")
    , @NamedQuery(name = "Mesameseroon.findByIDMesero", query = "SELECT m FROM Mesameseroon m WHERE m.iDMesero = :iDMesero")})
public class Mesameseroon implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "contador")
    private Integer contador;
    @Column(name = "ID_Mesa")
    private String iDMesa;
    @Column(name = "ID_Mesero")
    private String iDMesero;

    public Mesameseroon() {
    }

    public Mesameseroon(Integer contador) {
        this.contador = contador;
    }

    public Integer getContador() {
        return contador;
    }

    public void setContador(Integer contador) {
        this.contador = contador;
    }

    public String getIDMesa() {
        return iDMesa;
    }

    public void setIDMesa(String iDMesa) {
        this.iDMesa = iDMesa;
    }

    public String getIDMesero() {
        return iDMesero;
    }

    public void setIDMesero(String iDMesero) {
        this.iDMesero = iDMesero;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (contador != null ? contador.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mesameseroon)) {
            return false;
        }
        Mesameseroon other = (Mesameseroon) object;
        if ((this.contador == null && other.contador != null) || (this.contador != null && !this.contador.equals(other.contador))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Mesameseroon[ contador=" + contador + " ]";
    }
    
}
