/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author murdo
 */
@Entity
@Table(name = "mesas")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mesas.findAll", query = "SELECT m FROM Mesas m")
    , @NamedQuery(name = "Mesas.findByIDMesa", query = "SELECT m FROM Mesas m WHERE m.iDMesa = :iDMesa")})
public class Mesas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID_Mesa")
    private String iDMesa;
    @JoinColumn(name = "ID_Mesero", referencedColumnName = "ID_Mesero")
    @ManyToOne
    private Mesero iDMesero;

    public Mesas() {
    }

    public Mesas(String iDMesa) {
        this.iDMesa = iDMesa;
    }

    public String getIDMesa() {
        return iDMesa;
    }

    public void setIDMesa(String iDMesa) {
        this.iDMesa = iDMesa;
    }

    public Mesero getIDMesero() {
        return iDMesero;
    }

    public void setIDMesero(Mesero iDMesero) {
        this.iDMesero = iDMesero;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDMesa != null ? iDMesa.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mesas)) {
            return false;
        }
        Mesas other = (Mesas) object;
        if ((this.iDMesa == null && other.iDMesa != null) || (this.iDMesa != null && !this.iDMesa.equals(other.iDMesa))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Mesas[ iDMesa=" + iDMesa + " ]";
    }
    
}
