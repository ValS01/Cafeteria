/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author murdo
 */
@Entity
@Table(name = "platillo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Platillo.findAll", query = "SELECT p FROM Platillo p")
    , @NamedQuery(name = "Platillo.findByIDPlatillo", query = "SELECT p FROM Platillo p WHERE p.iDPlatillo = :iDPlatillo")
    , @NamedQuery(name = "Platillo.findByNombrePlatillo", query = "SELECT p FROM Platillo p WHERE p.nombrePlatillo = :nombrePlatillo")})
public class Platillo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID_Platillo")
    private String iDPlatillo;
    @Column(name = "NombrePlatillo")
    private String nombrePlatillo;
    @ManyToMany(mappedBy = "platilloCollection")
    private Collection<Ingredientes> ingredientesCollection;
    @OneToMany(mappedBy = "iDPlatillo")
    private Collection<Orden> ordenCollection;

    public Platillo() {
    }

    public Platillo(String iDPlatillo) {
        this.iDPlatillo = iDPlatillo;
    }

    public String getIDPlatillo() {
        return iDPlatillo;
    }

    public void setIDPlatillo(String iDPlatillo) {
        this.iDPlatillo = iDPlatillo;
    }

    public String getNombrePlatillo() {
        return nombrePlatillo;
    }

    public void setNombrePlatillo(String nombrePlatillo) {
        this.nombrePlatillo = nombrePlatillo;
    }

    @XmlTransient
    public Collection<Ingredientes> getIngredientesCollection() {
        return ingredientesCollection;
    }

    public void setIngredientesCollection(Collection<Ingredientes> ingredientesCollection) {
        this.ingredientesCollection = ingredientesCollection;
    }

    @XmlTransient
    public Collection<Orden> getOrdenCollection() {
        return ordenCollection;
    }

    public void setOrdenCollection(Collection<Orden> ordenCollection) {
        this.ordenCollection = ordenCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDPlatillo != null ? iDPlatillo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Platillo)) {
            return false;
        }
        Platillo other = (Platillo) object;
        if ((this.iDPlatillo == null && other.iDPlatillo != null) || (this.iDPlatillo != null && !this.iDPlatillo.equals(other.iDPlatillo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Platillo[ iDPlatillo=" + iDPlatillo + " ]";
    }
    
}
