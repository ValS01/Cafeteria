/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author murdo
 */
@Entity
@Table(name = "cajero")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cajero.findAll", query = "SELECT c FROM Cajero c")
    , @NamedQuery(name = "Cajero.findByIDCajero", query = "SELECT c FROM Cajero c WHERE c.iDCajero = :iDCajero")
    , @NamedQuery(name = "Cajero.findByNombre", query = "SELECT c FROM Cajero c WHERE c.nombre = :nombre")
    , @NamedQuery(name = "Cajero.findByTelefono", query = "SELECT c FROM Cajero c WHERE c.telefono = :telefono")
    , @NamedQuery(name = "Cajero.findByContrasenia", query = "SELECT c FROM Cajero c WHERE c.contrasenia = :contrasenia")})
public class Cajero implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID_Cajero")
    private String iDCajero;
    @Column(name = "Nombre")
    private String nombre;
    @Column(name = "Telefono")
    private String telefono;
    @Column(name = "Contrasenia")
    private String contrasenia;
    @OneToMany(mappedBy = "iDCajero")
    private Collection<Reservaciones> reservacionesCollection;
    @JoinColumn(name = "ID_Horario", referencedColumnName = "ID_Horario")
    @ManyToOne
    private Horario iDHorario;

    public Cajero() {
    }

    public Cajero(String iDCajero) {
        this.iDCajero = iDCajero;
    }

    public String getIDCajero() {
        return iDCajero;
    }

    public void setIDCajero(String iDCajero) {
        this.iDCajero = iDCajero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    @XmlTransient
    public Collection<Reservaciones> getReservacionesCollection() {
        return reservacionesCollection;
    }

    public void setReservacionesCollection(Collection<Reservaciones> reservacionesCollection) {
        this.reservacionesCollection = reservacionesCollection;
    }

    public Horario getIDHorario() {
        return iDHorario;
    }

    public void setIDHorario(Horario iDHorario) {
        this.iDHorario = iDHorario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDCajero != null ? iDCajero.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cajero)) {
            return false;
        }
        Cajero other = (Cajero) object;
        if ((this.iDCajero == null && other.iDCajero != null) || (this.iDCajero != null && !this.iDCajero.equals(other.iDCajero))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Cajero[ iDCajero=" + iDCajero + " ]";
    }
    
}
