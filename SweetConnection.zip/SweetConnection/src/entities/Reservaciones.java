/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author murdo
 */
@Entity
@Table(name = "reservaciones")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Reservaciones.findAll", query = "SELECT r FROM Reservaciones r")
    , @NamedQuery(name = "Reservaciones.findByIDReservacion", query = "SELECT r FROM Reservaciones r WHERE r.iDReservacion = :iDReservacion")
    , @NamedQuery(name = "Reservaciones.findByHora", query = "SELECT r FROM Reservaciones r WHERE r.hora = :hora")
    , @NamedQuery(name = "Reservaciones.findByNomCliente", query = "SELECT r FROM Reservaciones r WHERE r.nomCliente = :nomCliente")
    , @NamedQuery(name = "Reservaciones.findByFecha", query = "SELECT r FROM Reservaciones r WHERE r.fecha = :fecha")})
public class Reservaciones implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID_Reservacion")
    private String iDReservacion;
    @Column(name = "Hora")
    private String hora;
    @Column(name = "NomCliente")
    private String nomCliente;
    @Column(name = "Fecha")
    private String fecha;
    @JoinColumn(name = "ID_Cajero", referencedColumnName = "ID_Cajero")
    @ManyToOne
    private Cajero iDCajero;

    public Reservaciones() {
    }

    public Reservaciones(String iDReservacion) {
        this.iDReservacion = iDReservacion;
    }

    public String getIDReservacion() {
        return iDReservacion;
    }

    public void setIDReservacion(String iDReservacion) {
        this.iDReservacion = iDReservacion;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getNomCliente() {
        return nomCliente;
    }

    public void setNomCliente(String nomCliente) {
        this.nomCliente = nomCliente;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Cajero getIDCajero() {
        return iDCajero;
    }

    public void setIDCajero(Cajero iDCajero) {
        this.iDCajero = iDCajero;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDReservacion != null ? iDReservacion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reservaciones)) {
            return false;
        }
        Reservaciones other = (Reservaciones) object;
        if ((this.iDReservacion == null && other.iDReservacion != null) || (this.iDReservacion != null && !this.iDReservacion.equals(other.iDReservacion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Reservaciones[ iDReservacion=" + iDReservacion + " ]";
    }
    
}
