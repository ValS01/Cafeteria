/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author murdo
 */
@Entity
@Table(name = "ingredientes")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ingredientes.findAll", query = "SELECT i FROM Ingredientes i")
    , @NamedQuery(name = "Ingredientes.findByIDIngrediente", query = "SELECT i FROM Ingredientes i WHERE i.iDIngrediente = :iDIngrediente")
    , @NamedQuery(name = "Ingredientes.findByNomIngrediente", query = "SELECT i FROM Ingredientes i WHERE i.nomIngrediente = :nomIngrediente")
    , @NamedQuery(name = "Ingredientes.findByCaducidad", query = "SELECT i FROM Ingredientes i WHERE i.caducidad = :caducidad")
    , @NamedQuery(name = "Ingredientes.findByCantidad", query = "SELECT i FROM Ingredientes i WHERE i.cantidad = :cantidad")})
public class Ingredientes implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID_Ingrediente")
    private String iDIngrediente;
    @Column(name = "NomIngrediente")
    private String nomIngrediente;
    @Column(name = "Caducidad")
    private String caducidad;
    @Column(name = "Cantidad")
    private Integer cantidad;
    @JoinTable(name = "ingre_platillo", joinColumns = {
        @JoinColumn(name = "ID_Ingrediente", referencedColumnName = "ID_Ingrediente")}, inverseJoinColumns = {
        @JoinColumn(name = "ID_Platillo", referencedColumnName = "ID_Platillo")})
    @ManyToMany
    private Collection<Platillo> platilloCollection;

    public Ingredientes() {
    }

    public Ingredientes(String iDIngrediente) {
        this.iDIngrediente = iDIngrediente;
    }

    public String getIDIngrediente() {
        return iDIngrediente;
    }

    public void setIDIngrediente(String iDIngrediente) {
        this.iDIngrediente = iDIngrediente;
    }

    public String getNomIngrediente() {
        return nomIngrediente;
    }

    public void setNomIngrediente(String nomIngrediente) {
        this.nomIngrediente = nomIngrediente;
    }

    public String getCaducidad() {
        return caducidad;
    }

    public void setCaducidad(String caducidad) {
        this.caducidad = caducidad;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    @XmlTransient
    public Collection<Platillo> getPlatilloCollection() {
        return platilloCollection;
    }

    public void setPlatilloCollection(Collection<Platillo> platilloCollection) {
        this.platilloCollection = platilloCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDIngrediente != null ? iDIngrediente.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ingredientes)) {
            return false;
        }
        Ingredientes other = (Ingredientes) object;
        if ((this.iDIngrediente == null && other.iDIngrediente != null) || (this.iDIngrediente != null && !this.iDIngrediente.equals(other.iDIngrediente))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Ingredientes[ iDIngrediente=" + iDIngrediente + " ]";
    }
    
}
