/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author murdo
 */
@Entity
@Table(name = "mesero")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mesero.findAll", query = "SELECT m FROM Mesero m")
    , @NamedQuery(name = "Mesero.findByIDMesero", query = "SELECT m FROM Mesero m WHERE m.iDMesero = :iDMesero")
    , @NamedQuery(name = "Mesero.findByNombre", query = "SELECT m FROM Mesero m WHERE m.nombre = :nombre")
    , @NamedQuery(name = "Mesero.findByTelefono", query = "SELECT m FROM Mesero m WHERE m.telefono = :telefono")
    , @NamedQuery(name = "Mesero.findByContrasenia", query = "SELECT m FROM Mesero m WHERE m.contrasenia = :contrasenia")})
public class Mesero implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID_Mesero")
    private String iDMesero;
    @Column(name = "Nombre")
    private String nombre;
    @Column(name = "Telefono")
    private String telefono;
    @Column(name = "Contrasenia")
    private String contrasenia;
    @JoinColumn(name = "ID_Horario", referencedColumnName = "ID_Horario")
    @ManyToOne
    private Horario iDHorario;
    @OneToMany(mappedBy = "iDMesero")
    private Collection<Orden> ordenCollection;

    public Mesero() {
    }

    public Mesero(String iDMesero) {
        this.iDMesero = iDMesero;
    }

    public String getIDMesero() {
        return iDMesero;
    }

    public void setIDMesero(String iDMesero) {
        this.iDMesero = iDMesero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public Horario getIDHorario() {
        return iDHorario;
    }

    public void setIDHorario(Horario iDHorario) {
        this.iDHorario = iDHorario;
    }

    @XmlTransient
    public Collection<Orden> getOrdenCollection() {
        return ordenCollection;
    }

    public void setOrdenCollection(Collection<Orden> ordenCollection) {
        this.ordenCollection = ordenCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDMesero != null ? iDMesero.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mesero)) {
            return false;
        }
        Mesero other = (Mesero) object;
        if ((this.iDMesero == null && other.iDMesero != null) || (this.iDMesero != null && !this.iDMesero.equals(other.iDMesero))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Mesero[ iDMesero=" + iDMesero + " ]";
    }
    
}
