/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author murdo
 */
@Entity
@Table(name = "orden")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Orden.findAll", query = "SELECT o FROM Orden o")
    , @NamedQuery(name = "Orden.findByNumOrden", query = "SELECT o FROM Orden o WHERE o.numOrden = :numOrden")})
public class Orden implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "NumOrden")
    private Integer numOrden;
    @JoinColumn(name = "ID_Platillo", referencedColumnName = "ID_Platillo")
    @ManyToOne
    private Platillo iDPlatillo;
    @JoinColumn(name = "ID_Mesero", referencedColumnName = "ID_Mesero")
    @ManyToOne
    private Mesero iDMesero;
    @JoinColumn(name = "ID_mesa", referencedColumnName = "ID_Mesa")
    @ManyToOne
    private Mesas iDmesa;

    public Orden() {
    }

    public Orden(Integer numOrden) {
        this.numOrden = numOrden;
    }

    public Integer getNumOrden() {
        return numOrden;
    }

    public void setNumOrden(Integer numOrden) {
        this.numOrden = numOrden;
    }

    public Platillo getIDPlatillo() {
        return iDPlatillo;
    }

    public void setIDPlatillo(Platillo iDPlatillo) {
        this.iDPlatillo = iDPlatillo;
    }

    public Mesero getIDMesero() {
        return iDMesero;
    }

    public void setIDMesero(Mesero iDMesero) {
        this.iDMesero = iDMesero;
    }

    public Mesas getIDmesa() {
        return iDmesa;
    }

    public void setIDmesa(Mesas iDmesa) {
        this.iDmesa = iDmesa;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (numOrden != null ? numOrden.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Orden)) {
            return false;
        }
        Orden other = (Orden) object;
        if ((this.numOrden == null && other.numOrden != null) || (this.numOrden != null && !this.numOrden.equals(other.numOrden))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Orden[ numOrden=" + numOrden + " ]";
    }
    
}
