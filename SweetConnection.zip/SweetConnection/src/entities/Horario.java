/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author murdo
 */
@Entity
@Table(name = "horario")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Horario.findAll", query = "SELECT h FROM Horario h")
    , @NamedQuery(name = "Horario.findByIDHorario", query = "SELECT h FROM Horario h WHERE h.iDHorario = :iDHorario")
    , @NamedQuery(name = "Horario.findByHoraInicial", query = "SELECT h FROM Horario h WHERE h.horaInicial = :horaInicial")
    , @NamedQuery(name = "Horario.findByHoraFinal", query = "SELECT h FROM Horario h WHERE h.horaFinal = :horaFinal")})
public class Horario implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID_Horario")
    private String iDHorario;
    @Column(name = "Hora_Inicial")
    private String horaInicial;
    @Column(name = "Hora_Final")
    private String horaFinal;
    @OneToMany(mappedBy = "iDHorario")
    private Collection<Mesero> meseroCollection;
    @OneToMany(mappedBy = "iDHorario")
    private Collection<Cocinero> cocineroCollection;
    @OneToMany(mappedBy = "iDHorario")
    private Collection<Cajero> cajeroCollection;

    public Horario() {
    }

    public Horario(String iDHorario) {
        this.iDHorario = iDHorario;
    }

    public String getIDHorario() {
        return iDHorario;
    }

    public void setIDHorario(String iDHorario) {
        this.iDHorario = iDHorario;
    }

    public String getHoraInicial() {
        return horaInicial;
    }

    public void setHoraInicial(String horaInicial) {
        this.horaInicial = horaInicial;
    }

    public String getHoraFinal() {
        return horaFinal;
    }

    public void setHoraFinal(String horaFinal) {
        this.horaFinal = horaFinal;
    }

    @XmlTransient
    public Collection<Mesero> getMeseroCollection() {
        return meseroCollection;
    }

    public void setMeseroCollection(Collection<Mesero> meseroCollection) {
        this.meseroCollection = meseroCollection;
    }

    @XmlTransient
    public Collection<Cocinero> getCocineroCollection() {
        return cocineroCollection;
    }

    public void setCocineroCollection(Collection<Cocinero> cocineroCollection) {
        this.cocineroCollection = cocineroCollection;
    }

    @XmlTransient
    public Collection<Cajero> getCajeroCollection() {
        return cajeroCollection;
    }

    public void setCajeroCollection(Collection<Cajero> cajeroCollection) {
        this.cajeroCollection = cajeroCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDHorario != null ? iDHorario.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Horario)) {
            return false;
        }
        Horario other = (Horario) object;
        if ((this.iDHorario == null && other.iDHorario != null) || (this.iDHorario != null && !this.iDHorario.equals(other.iDHorario))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return iDHorario;
    }
    
}
